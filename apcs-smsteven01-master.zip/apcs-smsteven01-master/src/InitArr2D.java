import java.util.Arrays;

public class InitArr2D {
    public static void main(String[] args) {
        int[][] arr = new int[5][6];
        for (int r = 0; r < arr.length; r++) {
            for (int c = 0; c < arr[r].length; c++) {
                if (r == c) {
                    arr[r][c] = r;
                }
                else {
                    arr[r][c] = -1;
                }
            }
        }
        System.out.println(Arrays.deepToString(arr));
        System.out.println();
        for (int r = 0; r < arr.length; r++) {
            for (int c = 0; c < arr[r].length; c++) {
                System.out.print(arr[r][c] + " ");
            }
            System.out.println();
        }
    }
}
