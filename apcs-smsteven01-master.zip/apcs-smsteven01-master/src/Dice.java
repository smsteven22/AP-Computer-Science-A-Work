import java.util.Scanner;
public class Dice {
    public static void main(String[] args) {
        Scanner reader = new Scanner (System.in);
        int sides;
        System.out.print ("Enter a whole number: ");
        sides = reader.nextInt ();
        System.out.println("You entered: " + sides);

        int die_1 = (int)(Math.random() * sides + 1);
        int die_2 = (int)(Math.random() * sides + 1);
        int total = die_1 + die_2;

        System.out.println("Die 1: " + die_1);
        System.out.println("Die 2: " + die_2);
        System.out.println("Total: " + total);
    }
}
