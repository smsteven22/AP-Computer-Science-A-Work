public class Array {
    public static void main(String[] args) {
        String school1[] = new String[3];
        school1[0] = "Peak";
        school1[1] = "to";
        school1[2] = "Peak";

        String school2[] = {"Peak", "to", "Peak", "Charter", "School"};

        String full = concat(school2);
        System.out.println("Concat: " + full);


        for (int i = 0; i < 3; i++) {
            System.out.print(school1[i] + " ");
        }

        System.out.println();

        for (int j = 0; j < school2.length; j++) {
            System.out.print(school2[j] + " ");
        }
    }

    public static String concat (String[] arr) {
        String ret = "";
        for (int s = 0; s < arr.length; s++) {
            ret = ret + arr[s] + " ";
        }
        return ret;
    }
}
