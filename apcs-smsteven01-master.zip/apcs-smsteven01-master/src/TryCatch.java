import java.util.Scanner;

public class TryCatch {
    public static void main(String[] args) {
        Scanner reader = new Scanner (System.in);
        int val;
        System.out.print ("Enter an integer: ");

        try {
            // Put code that could throw an Exception inside a "try block"
            val  = reader.nextInt();
        }
        catch (Exception e) {
            // The "catch block" only runs if an Exception happens
            String wrong = reader.nextLine();
            System.out.println(wrong + " " + e);
            val = -1;
        }

        System.out.println(val);
    }
}
