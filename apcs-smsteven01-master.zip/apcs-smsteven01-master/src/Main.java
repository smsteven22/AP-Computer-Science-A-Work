public class Main {

    public static void main(String[] args) {
        System.out.println("Hello World!");
        System.out.println("VS Code is far superior to IntelliJ.");
        System.out.println("Just saying.....");
        System.out.println("Hello from my personal computer!");
    }
}
