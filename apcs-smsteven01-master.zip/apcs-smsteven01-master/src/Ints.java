public class Ints {

    public static void main(String[] args) {
        int x = 100;
        System.out.println(x);

        double y = 100.0;
        System.out.println(y);

        String z = "100";
        System.out.println(z);
    }
}
