public class SamIAm {
    public static void main(String[] args) {
        String[][] text = {
                {"That", "Sam-I-am!", "", "", "", "", "", ""},
                {"That", "Sam-I-am!", "", "", "", "", "", ""},
                {"I", "do", "not", "like", "that", "Sam-I-am!", "", ""},
                {"Do", "you", "like", "green", "eggs", "and", "ham?", ""},
                {"I", "do", "not", "like", "them,", "Sam-I-am.", "", ""},
                {"I", "do", "not", "like", "green", "eggs", "and", "ham."},
                {"Would", "you", "like", "them", "here", "or", "there?", ""},
                {"I", "would", "not", "like", "them", "here", "or", "there."},
                {"I", "would", "not", "like", "them", "anywhere.", "", ""},
                {"I", "do", "not", "like", "green", "eggs", "and", "ham."},
                {"I", "do", "not", "like", "them,", "Sam-I-am.", "", ""},
                {"Would", "you", "like", "them", "in", "a", "house?", ""},
                {"Would", "you", "like", "them", "with", "a", "mouse?", ""},
                {"I", "do", "not", "like", "them", "in", "a", "house."},
                {"I", "do", "not", "like", "them", "with", "a", "mouse."},
                {"I", "do", "not", "like", "them", "here", "or", "there."},
                {"I", "do", "not", "like", "them", "anywhere.", "", ""},
                {"I", "do", "not", "like", "green", "eggs", "and", "ham."},
                {"I", "do", "not", "like", "them,", "Sam-I-am.", "", ""},
                {"Would", "you", "eat", "them", "in", "a", "box?", ""},
                {"Would", "you", "eat", "them", "with", "a", "fox?", ""},
                {"Not", "in", "a", "box.", "Not", "with", "a", "fox."},
                {"Not", "in", "a", "house.", "Not", "with", "a", "mouse."},
                {"I", "would", "not", "like", "them", "here", "or", "there."},
                {"I", "would", "not", "like", "them", "anywhere.", "", ""},
                {"I", "do", "not", "like", "green", "eggs", "and", "ham."},
                {"I", "do", "not", "like", "them,", "Sam-I-am.", "", ""},
                {"Would", "you?", "Could", "you?", "In", "a", "car?", ""},
                {"eat", "them!", "eat", "them!", "Here", "they", "are!", ""},
                {"I", "would", "not,", "could", "not,", "in", "a", "car."},
                {"You", "may", "like", "them.", "You", "will", "see.", ""},
                {"You", "may", "like", "them", "in", "a", "tree.", ""},
                {"I", "would", "not,", "could", "not", "in", "a", "tree."},
                {"Not", "in", "a", "car!", "You", "let", "me", "be!"},
                {"I", "do", "not", "like", "them", "in", "a", "box."},
                {"I", "do", "not", "like", "them", "with", "a", "fox."},
                {"I", "do", "not", "like", "them", "in", "a", "house."},
                {"I", "do", "not", "like", "them", "with", "a", "mouse."},
                {"I", "do", "not", "lik", "them", "here", "or", "there."},
                {"I", "do", "not", "like", "them", "anywhere.", "", ""},
                {"I", "do", "not", "like", "green", "eggs", "and", "ham."},
                {"I", "do", "not", "like", "them,", "Sam-I-am.", "", ""},
                {"A", "train!", "A", "train!", "A", "train!", "A", "train!"},
                {"Could", "you,", "would", "you,", "on", "a", "train?", ""},
                {"Not", "in", "a", "train!", "Not", "in", "a", "tree!"},
                {"Not", "in", "car,", "Sam!", "Let", "me", "be!", ""},
                {"I", "would", "not,", "could", "not,", "in", "a", "box."},
                {"I", "would", "not,", "could", "not,", "with", "a", "fox."},
                {"I", "will", "not", "eat", "them", "with", "a", "mouse."},
                {"I", "will", "not", "eat", "them", "in", "a", "house."},
                {"I", "will", "not", "eat", "them", "here", "or", "there."},
                {"I", "will", "not", "eat", "them", "anywhere.", "", ""},
                {"I", "do", "not", "like", "green", "eggs", "and", "ham."},
                {"I", "do", "not", "like", "them,", "Sam-I-am.", "", ""}
        };

        // count and print the number of times "eggs" appears
        int count = 0;
        for (int r = 0; r < text.length; r++) {
            for (int c = 0; c < text[r].length; c++) {
                if (text[r][c].equals("eggs")) {
                    count++;
                }
            }
        }
        System.out.println("Number of occurances of 'eggs': " + count);
        System.out.println();

        // determine and print the average word length (ignore empty Strings)
        double sum = 0;
        double dividend = 0;
        for (int r = 0; r < text.length; r++) {
            for (int c = 0; c < text[r].length; c++) {
                if (text[r][c].length() != 0) {
                    if (text[r][c].contains(".") || text[r][c].contains("!") || text[r][c].contains("?") || text[r][c].contains(",")) {
                        sum = sum + (text[r][c].length() - 1);
                    }
                    else {
                        sum = sum + text[r][c].length();
                    }
                    dividend++;
                }
            }
        }
        double average = sum / dividend;
        System.out.println("Average word length: " + average);
    }
}
