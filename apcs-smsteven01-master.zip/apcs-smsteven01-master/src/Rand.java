public class Rand {
    public static void main(String[] args) {
        double r = Math.random() * 10.0;
        double r2 = Math.random() * 17.0;
        double r3 = Math.random() + 10.0;
        double r4 = Math.random() - 0.5;
        double r5 = Math.random() * 90.0 + 10.0;
        double r6 = (int)(Math.random() * 10);
        double r7 = Math.floor(Math.random() * 10);

        System.out.println(r);
        System.out.println(r2);
        System.out.println(r3);
        System.out.println(r4);
        System.out.println(r5);
        System.out.println(r6);
        System.out.println(r7);

        // Practice 1:
        double p1 = Math.random();
        double p2 = Math.random() * 100.0;
        double p3 = Math.random() + 5.0;
        double p4 = Math.random() * 20.0 - 10.0;
        int p5 = (int)(Math.random() * 100.0);
        int p6 = (int)(Math.random() * 52.0 + 1.0);

        System.out.println("[0.0, 1.0) is " + p1);
        System.out.println("[0.0, 100.0) is " + p2);
        System.out.println("[5.0, 6.0) is " + p3);
        System.out.println("[-10.0, 10.0) is " + p4);
        System.out.println("[0, 100] is " + p5);
        System.out.println("[1, 52] is " + p6);


    }
}
