import java.util.ArrayList;

public class ALRunner {
    public static void main(String[] args) {
        ArrayList list = new ArrayList();
        System.out.println(list);

        list.add ("A");
        list.add ("B");
        list.add(3);
        System.out.println(list);

        ArrayList<String> list2 = new ArrayList<String>();
        list2.add("C");
        list2.add("3");
        System.out.println(list2);

        list2.add(1, "Z");
        System.out.println(list2);

        list2.remove(2);
        System.out.println(list2);

        String s1 = list2.get(0);
        String s2 = list2.get(1);
        System.out.println("s1: " + s1);
        System.out.println("s2: " + s2);

        list2.set(0, s2);
        list2.set(1, s1);
        System.out.println(list2);

        for (String s: list2) {
            System.out.println(s);
        }


    }
}
