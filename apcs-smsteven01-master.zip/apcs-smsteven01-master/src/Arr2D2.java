import java.util.Arrays;

public class Arr2D2 {
    public static void main(String[] args) {
        int[][] table = new int[5][3];
        System.out.println(Arrays.deepToString(table));

        table[2][2] = 9;
        System.out.println(Arrays.deepToString(table));

        int[][] table2 = {{1, 2, 3}, {4, 5, 6}, {7, 8, 9}};
        System.out.println(Arrays.deepToString(table2));

        int[][] arr = new int[10][15];
        for (int r = 0; r < arr.length; r++) {
            for (int c = 0; c < arr[r].length; c++) {
                System.out.println(arr[r][c]);
            }
        }

        int[][] grid = new int[10][15];
        for (int[] row: grid) {
            for (int val: row) {
                System.out.println (val);
            }
        }

        double[][] dub = {{0.1, 0.2, 0.3, 0.5}, {1.1, 1.2, 1.3, 1.5}, {3.1, 3.2, 3.3, 3.5}};
        for (int r = 0; r < dub.length; r++) {
            for (int c = 0; c < dub[r].length; c++) {
                dub[r][c] = (dub[r][c] * 2.0);
            }
        }
        for (int r = 0; r < dub.length; r++) {
            for (int c = 0; c < dub[r].length; c++) {
                System.out.print(dub[r][c] + " ");
            }
            System.out.println();
        }
    }
}
