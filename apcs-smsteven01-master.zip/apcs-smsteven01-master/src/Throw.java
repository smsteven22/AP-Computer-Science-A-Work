import java.util.Scanner;

public class Throw {
    public static void main(String[] args) {
        Scanner reader = new Scanner(System.in);
        System.out.print("Enter a number between 1 and 10: ");

        int val = reader.nextInt();

        if (val < 1 || val > 10) {
            throw new IllegalArgumentException(val + " is not in the range 1 - 10, YOU FOOL. YOU DONUT.");
        }

        System.out.println("Thank you!");
    }
}
