import java.util.ArrayList;

public class AList {
    public static void main(String[] args) {
        ArrayList<Double> list = new ArrayList<>();

        for (int i = 0; i < 20; i++) {
            double val = (double)Math.random();
            list.add(val);
        }

        System.out.println(list);

        for (int i = 0; i<list.size(); i++) {
            Double get = list.get(i);
            get = get * -1.0;
            list.set(i, get);
        }

        System.out.println(list);

        Double smallest = list.get(0);
        for (Double val: list) {
            if (val < smallest) {
                smallest = val;
            }
        }
        System.out.println("Minimum: " + smallest);

        for (int i = 0; i < list.size(); i+=2) {
            list.add(i, 0.0);
        }
        System.out.println(list);

        for (int i = list.size()-1; i >= 0; i--) {
            if (list.get(i) > -0.5) {
                list.remove(i);
            }
        }
        System.out.println(list);

        /*
        int count = 0;
        double val = (double)Math.random();
        while (val != 0) {
            System.out.println(val);
            count++;
            val = (double)Math.random();
        }
        System.out.println(count);
         */
    }
}
