package apcs.csawesome_textbook_work;

import java.util.Scanner;

public class Adventure_CSAwesome {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        System.out.println("\n\n You are on an island surrounded by water.");
        System.out.println("There is a path to the woods to the north, the sea to the south, and a beach shack to the east.");
        System.out.println("Which way do you want to go (n,e,s,w)?");
        String command = scan.nextLine();
        if (command.equals("n")){
            System.out.println("You enter the forest and here some rustling.");
            System.out.println("There may be tigers here or maybe it's just monkeys.");
        }
        else if (command.equals("e")){
            System.out.println("You travel towards the beach shack and enter upon arriving.");
            System.out.println("There is an old lady making cakes with a very large oven.");
            System.out.println("She may or may not be suspicious.");
        }
        else if (command.equals("s")){
            System.out.println("You travel to the sea looking for some sort of boat or raft.");
            System.out.println("Near the waves is a small wooden raft and nothing else.");
        }
        else if (command.equals("w")){
            System.out.println("You search to the west of the island for anything promising.");
            System.out.println("You find nothing.");
        }
        else {
            System.out.println("You can't go in that direction.");
        }
    }
}
