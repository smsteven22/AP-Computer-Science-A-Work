package apcs.csawesome_textbook_work;

import java.util.Scanner;

public class Guessing_Game_CSAwesome {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        int random_number = (int)(Math.random() * 101);
        System.out.println(random_number);

        System.out.println("Enter a number: ");
        int user_guess = scan.nextInt();

        while (user_guess !=random_number){
            if (user_guess > random_number){
                System.out.println("Too high!");
            }
            else if (user_guess < random_number){
                System.out.println("Too low!");
            }
            else {
                System.out.println("That is an invalid answer. Please try again.");
            }
            user_guess = scan.nextInt();
        }
        System.out.println("You got it!");
        System.out.println("The number was " + random_number);

    }
}
