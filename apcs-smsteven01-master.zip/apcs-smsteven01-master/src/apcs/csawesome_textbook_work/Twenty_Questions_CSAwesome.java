package apcs.csawesome_textbook_work;

import java.util.Scanner;

public class Twenty_Questions_CSAwesome {
    // Copy in your link to your code on repl.it here:
// Copy in all of your code from repl.it below (include import and public class Main
    public static void main(String[] args) {
        System.out.println("\n\nLet's play 20 questions. Choose an animal and I will try to guess it!");
        Scanner scan = new Scanner(System.in);

        System.out.println("Is it a mammal (y/n)?");
        String answer = scan.nextLine();
        if (answer.equals("y")) {
            System.out.println("Is it a pet (y/n)?");
            answer = scan.nextLine();
            if (answer.equals("y")) {
                System.out.println("Does it play fetch (y/n)?");
                answer = scan.nextLine();
                if (answer.equals("y")) {
                    System.out.println("I guess a dog! Click on run to play again.");
                } else {
                    System.out.println("I guess a cat! Click on run to play again.");
                }
            } else {
                System.out.println("I guess an elephant! Click on run to play again.");
            }
        } else {
            System.out.println("Does it fly?");
            answer = scan.nextLine();
            if (answer.equals("y")) {
                System.out.println("I guess a bird! Click on run to play again.");
            } else {
                System.out.println("I guess a turtle! Click on run to play again.");
            }
        }
    }
}

