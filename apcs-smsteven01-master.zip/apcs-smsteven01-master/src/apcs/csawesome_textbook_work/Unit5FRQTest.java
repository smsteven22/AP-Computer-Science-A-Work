package apcs.csawesome_textbook_work;

public class Unit5FRQTest {
    private int num;
    private int add;
    private int start;

    public Unit5FRQTest() {
        this.num = 0;
        this.add = 1;
    }

    public Unit5FRQTest (int n1, int n2) {
        this.num = n1;
        this.start = n1;
        this.add = n2;
    }

    public int currentNumber() {
        return this.num;
    }

    public void next() {
        this.num += this.add;
    }

    public void prev() {
        if (this.num == this.start) {

        }
        else {
            this.num -= this.add;
        }
    }

    public String toString() {
        return "Number: " + this.num;
    }

    public static void main(String[] args) {
        Unit5FRQTest plus3 = new Unit5FRQTest (2, 3);
        plus3.currentNumber();
        System.out.println(plus3);
        plus3.next();
        plus3.currentNumber();
        System.out.println(plus3);
        plus3.next();
        plus3.next();
        plus3.currentNumber();
        System.out.println(plus3);
        plus3.prev();
        plus3.prev();
        plus3.prev();
        plus3.currentNumber();
        System.out.println(plus3);
        plus3.prev();
        plus3.currentNumber();
        System.out.println(plus3);
    }
}



