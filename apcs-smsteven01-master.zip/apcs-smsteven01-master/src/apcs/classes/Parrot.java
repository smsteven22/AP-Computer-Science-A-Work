package apcs.classes;

public class Parrot extends Bird{
    public Parrot() {
        // You can create constructors in subclasses that can "override" those in a superclass.
        // The Java keyword "super" refers to whatevery you are extending.
        super (16);
    }

    public Parrot (int weight) {
        super (weight);
    }

    // We say that Parrot "overrides" Bird's speak method.
    // Parrot's "speak" will be used INSTEAD OF Bird's.
    // Everything else is exactly the same as Bird.
    public void speak() {
        System.out.println("Polly want a cracker?");
    }
}
