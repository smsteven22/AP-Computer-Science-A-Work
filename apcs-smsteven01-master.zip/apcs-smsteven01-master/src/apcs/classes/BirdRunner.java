package apcs.classes;

public class BirdRunner {
    public static void main(String[] args) {
        Bird b = new Bird(3);
        // "Implicit" call to toString:
        System.out.println(b);
        b.speak();

        // Uses the "default" constructor:
        Bird b2 = new Bird();
        System.out.println(b2);
        b2.speak();

        // This is from Robin, which inherited toString AND speak.
        Robin r = new Robin();
        System.out.println(r);
        // A Robin doesn't have its own speak method, so it uses the one it inherited from Bird.
        r.speak();

        Parrot p = new Parrot();
        System.out.println(p);
        // A Parrot DOES have its own speak method, so it uses its own.
        p.speak();
    }
}
