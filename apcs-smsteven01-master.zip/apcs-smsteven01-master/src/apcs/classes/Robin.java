package apcs.classes;

public class Robin extends Bird{
    // "Extends" means that a Robin will automatically "inherit" ALL methods from Bird!
    // Only things that are unique to Robins need to be defined here.
    // If the class is empty, that means there are NO differences between a Robin and a generic Bird.

}
