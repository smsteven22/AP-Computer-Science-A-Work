package apcs.classes;

public class Bird {
    // Basic bird-like behaviors are defined here

    // instance variables
    private int weight; // weight in ounces
    // What we want to "remember" about each Bird.

    // Two Constructors!
    // A "default" constructor that sets instance variable(s) to a default value.
    public Bird() {
        this.weight = 5;
    }
    // An "overloaded" constructor that lets a runner set the instance variable(s).
    public Bird(int weight) {
        this.weight = weight;
    }

    // methods
    // Getter for weight
    public int getWeight() {
        return weight;
    }

    // Setter for weight
    public void setWeight(int weight) {
        this.weight = weight;
    }

    // The "speak" method just prints some chirping to the console.
    public void speak () {
        System.out.println("Cheep, Cheep, Cheep");
    }

    // toString just reports the values of instance variable(s).
    public String toString() {
        return "Bird{" + "weight=" + weight + '}';
    }
}
