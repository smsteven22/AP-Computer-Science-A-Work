package apcs.pi;

// Import Java Scanner class for use in prompting user input in part 1.
import java.util.Scanner;

public class PiRunner {
    public static void main(String[] args) {
        // Part 1: Approximate Pi by the number of terms:

        // Create new variable 'user_input_1' and set it to use imported scanner class for user input.
        Scanner user_input_1 = new Scanner(System.in);

        // Create new variable 'terms_1' to store 'user_input_1' results and use later in the loop to generate pi.
        int terms_1;

        // Print instructions for user input to the console to allow the user to gain a deeper understanding of the purpose of their input in the program.
        System.out.println("Please enter a number of terms used to approximate the value of Pi using Leibniz's equation. \nThe more terms you enter, the more accurate the assumption will be. ");

        // Retrieve user input using 'user_input_1' variable and store in pre-declared variable 'terms_1' to be used later in the loop to generate pi.
        terms_1 = user_input_1.nextInt();

        // Print a confirmation statement containing user-provided number of term to the console for the user to see.
        System.out.println("You entered: " + terms_1 + " terms.");

        // Declare and assign a new variable 'approximation_1' used to complete calculations and store the approximation of pi generated using the user-provided 'terms_1' variable.
        double approximation_1 = 0.0;

        // Declare and assign a new variable 'denominator_1' used to complete calculations for the denominator of each fraction piece of Leibniz's equation.
        double denominator_1 = 1.0;

        // Declare and assign a new variable 'numerator_1' used to complete calculations for each term of Leibniz's equation; stays constant throughout the program.
        double numerator_1 = 4.0;

        // Declare and assign a new variable 'fraction_1' used to complete calculations for the next term of Leibniz's equation for approximating pi; built by dividing 'numerator_1' value by 'denominator_1' value.
        double fraction_1 = numerator_1 / denominator_1;

        // Initialize a for loop to calculate pi approximation using user-provided number of terms stored in 'terms_1' variable.
        for (int count_1 = 1; count_1 < terms_1 + 1; count_1++){

            // Calculate next term value in Leibniz's equation using 'numerator_1' and 'denominator_1' values and store results in 'fraction_1' variable.
            fraction_1 = numerator_1 / denominator_1;

            // Initialize an if statement using the modulus to determine if a number is even or odd.
            if (count_1 % 2 == 0){
                // If the count value is even (remainder 0 when divided by 2):
                // Make the new fraction value added to approximation value negative.
                // Calculate new approximation value using previous approximation stored in 'approximation_1' and new term value stored in 'fraction_1'.
                approximation_1 = approximation_1 + (-1 * fraction_1);
            }

            else {
                // If the count value is odd (remainder > 0 when divided by 2):
                // Make the new fraction value added to the approximation value positive.
                // Calculate new approximation value using previous approximation stored in 'approximation_1' and new term value stored in 'fraction_1'.
                approximation_1 = approximation_1 + fraction_1;
            }

            // Add 2 to 'denominator_1' for the added fraction value to ensure correct use of Leibniz's equation.
            denominator_1 = denominator_1 + 2;
        }
        // When the loop is completed, print out approximated pi value for user to see.
        System.out.println("Pi approximation: " + approximation_1);

        System.out.println();
        System.out.println();

        // Part 2: Approximating Pi to a specific precision

        // Create new variable 'user_input_2' and set it use imported scanner class for user input.
        Scanner user_input_2 = new Scanner(System.in);

        // Create new variable 'terms_2' to store 'user_input_2' results and use later in the loop to generate pi.
        double terms_2;

        // Print instructions for user input to the console and allow the user to gain a deeper understanding of the purpose of their input in the program.
        System.out.println("Please enter a number representing the value of the smallest term used to approximate pi (threshold). \nThe greatest value the threshold can be is 4.0. \nThe smaller the threshold, the more accurate the assumption will be.");

        // Retrieve user input using 'user_input_2' variable and store in pre-declared variable 'terms_2' to be used later in the loop to generate pi.
        terms_2 = user_input_2.nextDouble();

        // Print a confirmation statement containing user-provided threshold value to the console for the user to see.
        System.out.println("You entered: " + terms_2 + " as the threshold value.");

        // Declare and assign a new variable 'approximation_2' used to complete calculations and store the approximation of pi generated using the user-provided 'terms_2' threshold variable.
        double approximation_2 = 0.0;

        // Declare and assign a new variable 'denominator_2' used to complete calculations for the denominator of each fraction piece of Leibniz's equation.
        double denominator_2 = 1.0;

        // Declare and assign a new variable 'numerator_2' used to complete calculations for each term of Leibniz's equation; stays constant throughout the program.
        double numerator_2 = 4.0;

        // Declare and assign a new variable 'fraction_2' used to complete calculations for the next term of Leibniz's equation for approximating pi; built by dividing 'numerator_2' value by 'denominator_2' value.
        double fraction_2 = numerator_2 / denominator_2;

        // Declare and assign a new variable 'count_2' used to count number of iterations through the loop and determine the sign (+ or -) of the next term in Leibniz's equation.
        int count_2 = 1;

        // Initialize a while loop to calculate pi approximation using user-provided threshold term stored in 'terms_2' variable.
        while (fraction_2 >= terms_2) {

            // Calculate next term value in Leibniz's equation using 'numerator_2' and 'denominator_2' values and store result in 'fraction_2' variable.
            fraction_2 = numerator_2 / denominator_2;

            // Initialize an if statement using the modulus to determine if a number is even or odd.
            if (count_2 % 2 == 0) {
                // If the count value is even (remainder 0 when divided by 2):
                // Make the new fraction value added to the approximation value negative.
                // Calculate new approximation value using previous approximation stored in 'approximation_2' and new term value stored in 'fraction_2'.
                approximation_2 = approximation_2 + (-1 * fraction_2);
            }
            else {
                // If the count value is odd (remainder > 0 when divided by 2):
                // Make the new fraction value added to the approximation value positive.
                // Calculate new approximation value using previous approximation stored in 'approximation_2' and new term value stored in 'fraction_2'.
                approximation_2 = approximation_2 + fraction_2;
            }

            // Add 2 to 'denominator_2' for the added fraction value to ensure correct use of Leibniz's equation.
            denominator_2 = denominator_2 + 2;

            // Add 1 to 'count_2' to signify one iteration through the loop complete; used to determine sign (+ or -) of next term value in Leibniz's equation.
            count_2 = count_2 + 1;
        }
        // When the loop is completed, print out approximated pi value for user to see.
        System.out.println("Pi approximation: " + approximation_2);

        System.out.println();
        System.out.println();

        // Part 3: Approximate pi using random number generation and counting

        // Create new variable 'user_input_3' and set it to use imported scanner class for user input.
        Scanner user_input_3 = new Scanner(System.in);

        // Create new variable 'terms_3' to store 'user_input_1' results and use later in the loop to generate pi.
        int terms_3;

        // Print instructions for user input to the console to allow the user to gain a deeper understanding of the purpose of their input in the program.
        System.out.println("Please enter a number of coordinate points used to approximate the value of Pi using Leibniz's equation. \nThe more points you enter, the more accurate the assumption will be.");

        // Retrieve user input using 'user_input_3' variable and store in pre-declared variable 'terms_3' to be used later in the loop to generate pi.
        terms_3 = user_input_3.nextInt();

        // Print a confirmation statement containing user-provided number of term to the console for the user to see.
        System.out.println("You entered: " + terms_3 + " points.");

        // Declare and assign a new variable 'points_in' used to store number of points that land within the unit circle based on the user-provided total number of terms in 'terms_3' variable to be used later with Pi approximation calculations.
        double points_in = 0;

        // Declare and assign a new variable 'approximation_3' used to complete calculations and store the approximation of pi generated using 'points_in' variable and 'terms_3' variable.
        double approximation_3;

        // Declare an assign a new variable 'ratio' used to calculate the ratio of random points within the unit circle using the number of points that fell in the circle ('points_in') and the total number of points ('terms_3').
        double ratio;

        // Declare and assign a new variable 'x_coordinate' using Math.random() function to generate a random x-coordinate within a square.
        double x_coordinate = Math.random() * 2.0 - 1.0;

        // Declare and assign a new variable 'y_coordinate' using Math.random() function to generate a random y-coordinate within a square.
        double y_coordinate = Math.random() * 2.0 - 1.0;

        // Declare a new variable 'radius' to be used later to count points that fall within the unit circle.
        double radius;

        // Initialize a for loop to calculate pi approximation using user-provided number of terms stored in 'terms_3' variable.
        for (int count_3 = 1; count_3 <= terms_3; count_3++)  {
            // Take the two randomly generated coordinates and complete pythagorean theorem to find if the two points lie within the unit circle.
            radius = (x_coordinate * x_coordinate) + (y_coordinate * y_coordinate);

            // If the two points lie within the unit circle, add one to the 'points_in' variable to signify one more point in the ratio.
            if (radius < 1) {
                points_in = points_in + 1;
            }

            // Regenerate random x-coordinate value for next iteration of the for loop.
            x_coordinate = Math.random() * 2.0 - 1.0;

            // Regenerate random y-coordinate value for next iteration of the for loop.
            y_coordinate = Math.random() * 2.0 - 1.0;
        }

        // Take the calculated number of coordinate points within the circle and divide by total number of points to find pi/4 approximation.
        ratio = points_in / terms_3;

        // Multiply pi/4 approximation (variable 'ratio') by 4 to obtain pi approximataion.
        approximation_3 = 4 * ratio;

        // When the loop and calculations are completed, print out the total number of points generated inside the unit circle for user to see.
        System.out.println("Generated points: " + terms_3);

        // When the loop and calculations are completed, print out the number of points generated inside the unit circle for user to see.
        System.out.println("Points generated inside unit circle: " + points_in);

        // When the loop and calculations are completed, print out approximated pi/4 value for user to see.
        System.out.println("Pi/4 approximation: " + ratio);

        // When the loop and calculations are completed, print out approximated pi value for user to see.
        System.out.println("Pi approximation: " + approximation_3);
    }
}
