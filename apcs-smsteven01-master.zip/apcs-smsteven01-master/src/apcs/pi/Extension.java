package apcs.pi;

import java.util.Scanner;

public class Extension {
    public static void main(String[] args) {
        /*
            I completed an extension: This program now takes the user-provided terms and approximates the value of e
            using the factorial elements within a series: 1 + 1/1! + 1/2! + 1/3! + 1/4! + ... + 1/n!. The program uses
            a counting for loop to aid in not only the counting to limit the loop to the user-provided number of terms,
            but also the factorial calculations and the denominator construction of the fraction containing the
            factorial.

            It demonstrates mastery because it utilizes a for loop in multiple ways within that one loop, instead of
            just a counting loop that adds a time limit for the program to complete. In addition, this program
            demonstrates mastery because I was able to get a fairly accurate approximation of e by applying an equation
            to a Java loop with no outside help.
         */
        Scanner user_input_extension = new Scanner(System.in);

        double terms_extension;

        System.out.println("Please enter a number of terms used to approximate the value of e using factorials. \nThe more terms you enter, the more accurate the assumption will be. ");
        terms_extension = user_input_extension.nextInt();

        System.out.println("You entered: " + terms_extension + " terms.");

        double factorial_extension = 1;
        double approximation_extension = 1;

        for (double factorial_count_extension = 1; factorial_count_extension < terms_extension + 1; factorial_count_extension++) {
            factorial_extension = factorial_extension * factorial_count_extension;

            approximation_extension = approximation_extension + (1 / factorial_extension);
        }

        System.out.println();
        System.out.println("e approximation: " + approximation_extension);
    }
}
