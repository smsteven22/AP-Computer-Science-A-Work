package apcs.life;

import info.gridworld.actor.Actor;
import info.gridworld.actor.ActorWorld;
import info.gridworld.grid.Location;
import info.gridworld.grid.UnboundedGrid;

public class LifeRunner {
    public static void main(String[] args) {
        UnboundedGrid<Actor> gr = new UnboundedGrid<Actor>();
        ActorWorld world = new ActorWorld(gr);
/*
        world.add(new Location(8, 5), new Cell(56));
        world.add(new Location(7, 4), new Cell(35));
        world.add(new Location(7, 5), new Cell(22));
        world.add(new Location(6, 5), new Cell(33));
        world.add(new Location(7, 7), new Cell(20));
        world.add(new Location(7, 6), new Cell(39));
        world.add(new Location(7, 8), new Cell(67));
        world.add(new Location(5, 3), new Cell(7));
        world.add(new Location(5, 2), new Cell(23));
        world.add(new Location(6, 4), new Cell(15));
        world.add(new Location(6, 3), new Cell(80, 15, 45));
        world.add(new Location(7, 3), new Cell(31, 99, 18, 50));
        world.add(new Location(5, 6), new Cell(20));
        world.add(new Location(5, 7), new Cell(21));

 */

        world.add(new Location (2, 0),new Cell(20));
        world.add(new Location (2, 1),new Cell(20));
        world.add(new Location (2, 2),new Cell(20));
        world.add(new Location (1, 2),new Cell(20));
        world.add(new Location (0, 1),new Cell(20));

        world.show();
    }
}
