package apcs.life;

import info.gridworld.actor.Actor;
import info.gridworld.grid.Grid;
import info.gridworld.grid.Location;

import java.awt.*;
import java.util.ArrayList;

/*
I completed an Extension: I have added in the capability for the cells to die of old age and only produce
another cell if they are within the fertility window. This is achieved by including four more instance
variables: age, maxAge, fertileAgeLow, and fertileAgeHigh. Multiple constructors have been added so that the
user can specify the cell's starting age, maximum age, minimum fertile age, and maximum fertile age. Multiple
constructors have been added so the user can set these values in many different combinations. Once the four
instance variables have been instantiated, they are used in phase 1 to determine whether the cell dies, or if
the cell can produce another cell using comparison statements such as >=, <=, and >.

This extension demonstrates mastery because it utilizes even more comparisons and operations to make the program
even more realistic. It also demonstrates a deeper understanding of additional constructors within a class.
Finally, this extension demonstrates the critical thinking needed within programming through the new conditions
that must be met for a cell to die or reproduce. These new conditions demonstrate critical thinking because the
program's outcome needed to be fully understood and the code needed to be combed through in order to place the
comparison statements in the correct place so that the program works as intended.
 */

public class Cell extends Actor {
    private boolean willDie;
    private int phase;
    private ArrayList<Location> addCells;
    private int age;
    private int maxAge;
    private int fertileAgeLow;
    private int fertileAgeHigh;

    public Cell() {
        this.phase = 1;
        this.willDie = false;
        this.addCells = new ArrayList<Location>();
        super.setColor(Color.RED);
        this.age = 0;
        this.maxAge = 75;
        this.fertileAgeLow = 20;
        this.fertileAgeHigh = 40;
    }

    public Cell(int userAge) {
        this.phase = 1;
        this.willDie = false;
        this.addCells = new ArrayList<Location>();
        super.setColor(Color.RED);
        this.age = userAge;
        this.maxAge = 75;
        this.fertileAgeLow = 20;
        this.fertileAgeHigh = 40;
    }

    public Cell(int userLow, int userHigh) {
        this.phase = 1;
        this.willDie = false;
        this.addCells = new ArrayList<Location>();
        super.setColor(Color.RED);
        this.age = 0;
        this.maxAge = 75;
        this.fertileAgeLow = userLow;
        this.fertileAgeHigh = userHigh;
    }

    public Cell(int userMax, int userLow, int userHigh) {
        this.phase = 1;
        this.willDie = false;
        this.addCells = new ArrayList<Location>();
        super.setColor(Color.RED);
        this.age = 0;
        this.maxAge = userMax;
        this.fertileAgeLow = userLow;
        this.fertileAgeHigh = userHigh;
    }

    public Cell (int userAge, int userMax, int userLow, int userHigh) {
        this.phase = 1;
        this.willDie = false;
        this.addCells = new ArrayList<Location>();
        super.setColor(Color.RED);
        this.age = userAge;
        this.maxAge = userMax;
        this.fertileAgeLow = userLow;
        this.fertileAgeHigh = userHigh;
    }

    public Cell(Color color, int userAge, int userMax, int userHigh, int userLow) {
        this.phase = 1;
        this.willDie = false;
        this.addCells = new ArrayList<Location>();
        super.setColor(color);
        this.age = userAge;
        this.maxAge = userMax;
        this.fertileAgeLow = userHigh;
        this.fertileAgeHigh = userLow;
    }


    public void act() {
        if (this.phase == 1) {
            this.phase1();
            this.phase = 2;
        }
        else {
            this.phase2();
            this.phase = 1;
        }
    }

    public void phase1() {
        Grid<Actor> cellGrid = this.getGrid();
        ArrayList<Location> neighbors = cellGrid.getOccupiedAdjacentLocations(this.getLocation());
        ArrayList<Location> empty = cellGrid.getEmptyAdjacentLocations(this.getLocation());
        if (neighbors.size() > 3 || neighbors.size() < 2 || age > maxAge) {
            this.willDie = true;
        }
        for (Location emptyLocation: empty) {
            ArrayList<Location> emptyNeighbors = cellGrid.getOccupiedAdjacentLocations(emptyLocation);
            if (emptyNeighbors.size() == 3 && age >= fertileAgeLow && age <= fertileAgeHigh) {
                this.addCells.add(emptyLocation);
            }
        }
        age++;
    }

    public void phase2() {
        Grid<Actor> newCellGrid = this.getGrid();
        if (this.willDie == true) {
            this.removeSelfFromGrid();
        }
        for (Location add: addCells) {
            if (newCellGrid.get(add) == null) {
                Cell newCell = new Cell();
                newCell.putSelfInGrid(newCellGrid, add);
            }
        }
        for (int i = addCells.size()-1; i >= 0; i--) {
            addCells.remove(i);
        }
    }

    @Override
    public String toString() {
        return "Cell{" +
                "willDie=" + willDie +
                ", phase=" + phase +
                ", addCells=" + addCells +
                '}';
    }
}
