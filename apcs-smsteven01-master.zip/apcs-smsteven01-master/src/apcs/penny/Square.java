package apcs.penny;

public class Square {
    private int score;
    private boolean occupied;
    private int pennies;

    public Square(int userScore) {
        this.score = userScore;
        this.occupied = false;
    }

    public int getScore() {
        return this.score;
    }

    public boolean getOccupied() {
        return this.occupied;
    }

    public int getPennies() {
        return this.pennies;
    }

    public void setScore(int newScore) {
        this.score = newScore;
    }

    public void setOccupied(boolean newOccupied) {
        this.occupied = newOccupied;
    }

    public void setPennies(int newPennies) {
        this.pennies = newPennies;
    }

    public String toString() {
        if (this.occupied == false) {
            return "" + this.score;
        }
        else if (this.pennies == 2) {
            return "=";
        }
        else if (this.pennies >= 3) {
            return "≣";
        }
        return "-";
    }
}
