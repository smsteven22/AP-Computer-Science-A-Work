package apcs.penny;

import java.util.Scanner;

public class Runner {
    public static void main(String[] args) {
        Square[][] board = new Square[5][5];

        for (int r = 0; r < board.length; r++) {
            for (int c = 0; c < board[r].length; c++) {
                if (r == 2 && c == 2) {
                    board[r][c] = new Square(3);
                }
                else if (r == 0 || r == 4 || c == 0 || c == 4) {
                    board[r][c] = new Square(1);
                }
                else {
                    board[r][c] = new Square(2);
                }
            }
        }

        for (int r = 0; r < board.length; r++) {
            for (int c = 0; c < board[r].length; c++) {
                System.out.print(board[r][c] + " ");
            }
            System.out.println();
        }

        int pennyCount = 1;
        int random1;
        int random2;
        int totalScore = 0;
        while (pennyCount <= 5) {
            Scanner reader = new Scanner(System.in);
            System.out.print("Press any key to toss penny number " + pennyCount);
            String response = reader.nextLine();

            random1 = (int) (Math.random() * 5);
            random2 = (int) (Math.random() * 5);

            if (board[random1][random2].getOccupied() == true) {
                System.out.println("You hit row " + random1 + " and column " + random2);
                System.out.println("Congratulations! Your amazing luck resulted in you hitting the same location twice! The score for this penny will be doubled!");
                Square get = board[random1][random2];
                get.setOccupied(true);
                int doubleScore = get.getScore() * 2;
                totalScore = totalScore + doubleScore;

                int numPennies = get.getPennies();
                get.setPennies(numPennies + 1);

                for (int r = 0; r < board.length; r++) {
                    for (int c = 0; c < board[r].length; c++) {
                        System.out.print(board[r][c] + " ");
                    }
                    System.out.println();
                }

                System.out.println("You scored " + doubleScore + "! Your total score is now " + totalScore);
                System.out.println();
            }
            else {
                System.out.println("You hit row " + random1 + " and column " + random2);
                Square get = board[random1][random2];
                get.setOccupied(true);
                totalScore = totalScore + get.getScore();

                int numPennies = get.getPennies();
                get.setPennies(numPennies + 1);

                for (int r = 0; r < board.length; r++) {
                    for (int c = 0; c < board[r].length; c++) {
                        System.out.print(board[r][c] + " ");
                    }
                    System.out.println();
                }

                System.out.println("You scored " + get.getScore() + "! Your total score is now " + totalScore);
                System.out.println();
            }

            pennyCount++;
        }
        if (totalScore >= 9) {
            System.out.println("You scored greater than 9 points (" + totalScore + " points to be exact)! You're a winner!");
        }
        else {
            System.out.println("You scored fewer than 9 points (" + totalScore + " points to be exact). Sorry, you're a loser.");
        }
    }
}
