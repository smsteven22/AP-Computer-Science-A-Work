package apcs.turtles;

import TurtleGraphics.SketchPadWindow;

public class BurstRunner {
    public static void main(String[] args) {
        SketchPadWindow sk = new SketchPadWindow(800, 800);
        SlowPen p = new SlowPen(sk, 100);
        burst(p, 150);
    }

    public static void burst(SlowPen p, int dist) {
        if (dist == 0) {
            return;
        }
        else {
            p.move(dist);
            p.turn(175);
            burst(p, dist-1);
        }
    }
}
