package apcs.turtles;

import TurtleGraphics.Pen;

public class Wheel extends Circle {
    protected int spokes;

    public Wheel () {
        super();
        this.spokes = 3;
    }

    public Wheel(int s) {
        super();
        this.spokes = s;
    }

    public Wheel (double x, double y, double r, int s) {
        this.xPos = x;
        this.yPos = y;
        this.radius = r;
        this.spokes = s;
    }

    public int getSpokes () {
        return this.spokes;
    }

    public void setSpokes (int spokes) {
        this.spokes = spokes;
    }

    public void draw(Pen p) {
        int angle = 360 / this.spokes;
        super.draw(p);
        p.up();
        p.move(this.xPos, this.yPos);
        p.setDirection(0);
        p.down();
        for (int i = 0; i < this.spokes; i++) {
            p.move(this.radius);
            p.up();
            p.move(xPos, yPos);
            p.setDirection((i + 1) * angle);
            p.down();
        }
    }

    public String toString() {
        return super.toString() + "; spokes: " + this.spokes;
    }

}
