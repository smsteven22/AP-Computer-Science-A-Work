package apcs.turtles;

import TurtleGraphics.SketchPadWindow;

public class ZigzagRunner {
    public static void main(String[] args) {
        SketchPadWindow sk = new SketchPadWindow(800, 800);
        SlowPen p = new SlowPen(sk, 100);
        zigzag(p, 150);
    }

    public static void zigzag(SlowPen p, int dist) {
        p.move(dist);
        p.setDirection(-88);
        p.move(dist-1);
        p.setDirection(88);
        zigzag(p, dist-2);
    }
}
