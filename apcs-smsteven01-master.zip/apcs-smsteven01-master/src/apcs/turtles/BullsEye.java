package apcs.turtles;

import TurtleGraphics.Pen;

public class BullsEye extends Circle {
    protected int rings;

    public BullsEye() {
        super();
        this.rings = 2;
    }

    public BullsEye(double x, double y, double r1, int ri) {
        super(x, y, r1);
        this.rings = ri;
    }

    public void draw (Pen p) {
        double tempRadius = this.radius;
        for (int i = 0; i < this.rings; i++) {
            super.draw(p);
            this.radius = this.radius * 2;
        }

        this.radius = tempRadius;
    }

    public String toString() {
        return (super.toString() + " Rings: " + this.rings);
    }
}
