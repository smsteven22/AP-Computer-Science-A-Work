package apcs.turtles;

import TurtleGraphics.RainbowPen;
import TurtleGraphics.SketchPadWindow;

public class ZigZag {
    public static void main(String[] args) {
        SketchPadWindow sk = new SketchPadWindow(400, 400);
        RainbowPen p1 = new RainbowPen(sk);

        p1.up();
        p1.move(-200, 0);
        p1.down();

        int y = -150;

        for (int x = -200; x <= 200; x+=20) {
            p1.move(x, y);
            if (y == -150) {
                y = 150;
            }
            else {
                y = -150;
            }
        }
    }
}
