package apcs.turtles;

import java.awt.*;

public class Square extends Rect {
    public Square() {
        super();
    }

    public Square(double x, double y, double l, double w) {
        super(x, y, l, w);
    }

    public Square(double x, double y, double s) {
        super(x, y, s, s);
    }
}
