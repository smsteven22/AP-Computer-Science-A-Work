package apcs.turtles;

import TurtleGraphics.Pen;

public class NGon implements Shape {
    private double xPos;
    private double yPos;
    private double length;
    private double radius;
    private double sides;

    public NGon(){
        xPos = 0;
        yPos = 0;
        length = 1;
        radius = 1;
        sides = 4;
    }

    public NGon(double x, double y, double l, double r, double s) {
        xPos = x;
        yPos = y;
        length = l;
        radius = r;
        sides = s;
    }

    @Override
    public double getXPos() {
        return this.xPos;
    }

    @Override
    public double getYPos() {
        return this.yPos;
    }

    @Override
    public void move(double xPos, double yPos) {
        this.xPos = xPos;
        this.yPos = yPos;
    }

    @Override
    public void stretchBy(double factor) {
        this.length = this.length * factor;
    }

    @Override
    public double area() {
        return ((radius * (sides * length))/2);
    }

    @Override
    public void draw(Pen p) {
        p.up();
        p.move(xPos + (length/2), yPos-radius);
        p.down();

        double angle = 360/sides;
        p.setDirection(angle-90);
        for (int i = 0; i < this.sides; i++) {
            p.move(length);
            p.turn(angle);
        }
    }

    public String toString() {
        return ("n-gon: center = (" + this.xPos + ", " + this.yPos + "); length = " + this.length + "; sides = " + this.sides);
    }
}
