package apcs.turtles;

import TurtleGraphics.*;

import java.awt.*;

public class TurtleRunner2 {
    public static void main(String[] args) {
        SketchPadWindow sk1 = new SketchPadWindow(500, 500);
        StandardPen p1 = new StandardPen(sk1);
        drawSquare(90, Color.RED, p1);

        SketchPadWindow sk2 = new SketchPadWindow(500, 500);
        WigglePen p2 = new WigglePen(sk2);
        drawSquare(90, Color.PINK, p2);

        SketchPadWindow sk3 = new SketchPadWindow(500, 500);
        RainbowPen p3 = new RainbowPen(sk3);
        drawSquare(90, Color.GREEN, p3);

        SketchPadWindow sk4 = new SketchPadWindow(500, 500);
        WiggleRainbowPen p4 = new WiggleRainbowPen(sk4);
        drawSquare(90, Color.BLUE, p4);
    }

    private static void drawSquare (double side, Color col, Pen p) {
        p.up();
        p.home();
        p.setColor(col);
        p.move(side/2.0);
        p.turn(90);
        p.move(side/2.0);
        p.down();
        for (int i = 0; i < 4; i++) {
            p.turn(90);
            p.move(side);
        }
    }
}
