package apcs.turtles;

import TurtleGraphics.*;

public class TurtleRunner {
    public static void main(String[] args) {
        SketchPadWindow sk = new SketchPadWindow(500, 500);
        StandardPen pen = new StandardPen(sk);
        pen.up();
        pen.setDirection(0);
        pen.move(25);
        pen.setDirection(270);
        pen.move(25);
        pen.setDirection(90);
        pen.down();
        for (int i = 0; i < 4; i++) {
            pen.move(50);
            pen.turn(90);
        }

        SketchPadWindow sk2 = new SketchPadWindow(500, 500);
        WigglePen p2 = new WigglePen(sk2);
        p2.up();
        p2.setDirection(90);
        p2.move(24);
        p2.setDirection(180);
        p2.move(26);
        p2.turn(120);
        p2.down();
        for (int i = 0; i < 3; i++) {
            p2.move(52);
            p2.turn(120);
        }

        SketchPadWindow sk3 = new SketchPadWindow(500, 500);
        RainbowPen p3 = new RainbowPen (sk3);
        p3.up();
        p3.setDirection(90);
        p3.move(50);
        p3.turn(144);
        p3.down();
        for (int i = 0; i < 5; i++) {
            p3.move(100);
            p3.turn(144);
        }

        SketchPadWindow sk4 = new SketchPadWindow(500, 500);
        WiggleRainbowPen p4 = new WiggleRainbowPen(sk4);
        p4.up();
        p4.setDirection(90);
        p4.move(100);
        p4.turn(90);
        p4.down();
        for (int i = 0; i < 360; i++) {
          p4.move(2);
          p4.turn(1);
        }
    }
}
