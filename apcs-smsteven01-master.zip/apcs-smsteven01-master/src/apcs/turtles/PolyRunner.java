package apcs.turtles;

import TurtleGraphics.*;

import java.util.ArrayList;
import java.util.Scanner;

public class PolyRunner {
    public static void main(String[] args) {
        ArrayList<Shape> shapes = new ArrayList<Shape>();
        shapes.add(new Rect (-10.0, 10.0, 20.0, 20.0));
        shapes.add(new Circle (10.0, 10.0, 10.0));
        shapes.add(new Wheel (10.0, -10.0, 10.0, 6));
        Pen p = new SlowPen (10);
        for (Shape s: shapes) {
            s.draw (p);
            System.out.println (s);
        }

        ArrayList<Shape> userShapes = new ArrayList<Shape>();
        Scanner reader = new Scanner (System.in);
        int option;
        int shapeOption;
        System.out.print("Please choose an option by typing the option number: \n1. Add a Shape \n2. Draw \n9. Quit\n ");
        option = reader.nextInt ();
        System.out.println();
        while (option != 9) {
            if (option == 1) {
                System.out.print("Please choose a shape to add by typing the shape number: \n1. Circle \n2. Wheel \n3. Bulls Eye \n4. Rectangle \n5. Square \n6. N-Gon\n ");
                shapeOption = reader.nextInt();
                System.out.println();
                if (shapeOption == 1) {
                    double x;
                    double y;
                    double r;
                    System.out.print("Please enter a value for the circle's x-coordinate: ");
                    x = reader.nextDouble();
                    System.out.println();

                    System.out.print("Please enter a value for the circle's y-coordinate: ");
                    y = reader.nextDouble();
                    System.out.println();

                    System.out.print("Please enter a value for the circle's radius: ");
                    r = reader.nextDouble();
                    System.out.println();

                    userShapes.add(new Circle(x, y, r));
                }
                else if (shapeOption == 2) {
                    double x;
                    double y;
                    double r;
                    int s;

                    System.out.print("Please enter a value for the wheel's x-coordinate: ");
                    x = reader.nextDouble();
                    System.out.println();

                    System.out.print("Please enter a value for the wheel's y-coordinate: ");
                    y = reader.nextDouble();
                    System.out.println();

                    System.out.print("Please enter a value for the wheel's radius: ");
                    r = reader.nextDouble();
                    System.out.println();

                    System.out.print("Please enter a value for the wheel's number of spokes: ");
                    s = reader.nextInt();
                    System.out.println();

                    userShapes.add(new Wheel(x, y, r, s));
                }
                else if (shapeOption == 3) {
                    double x;
                    double y;
                    double r;
                    int ri;

                    System.out.print("Please enter a value for the Bulls Eye's x-coordinate: ");
                    x = reader.nextDouble();
                    System.out.println();

                    System.out.print("Please enter a value for the Bulls Eye's y-coordinate: ");
                    y = reader.nextDouble();
                    System.out.println();

                    System.out.print("Please enter a value for the Bulls Eye's radius: ");
                    r = reader.nextDouble();
                    System.out.println();

                    System.out.print("Please enter a value for the Bulls Eye's number of rings: ");
                    ri = reader.nextInt();
                    System.out.println();

                    userShapes.add(new BullsEye(x, y, r, ri));
                }
                else if (shapeOption == 4) {
                    double x;
                    double y;
                    double h;
                    double w;

                    System.out.print("Please enter a value for the rectangle's x-coordinate: ");
                    x = reader.nextDouble();
                    System.out.println();

                    System.out.print("Please enter a value for the rectangle's y-coordinate: ");
                    y = reader.nextDouble();
                    System.out.println();

                    System.out.print("Please enter a value for the rectangle's height: ");
                    h = reader.nextDouble();
                    System.out.println();

                    System.out.print("Please enter a value for the rectangle's width: ");
                    w = reader.nextDouble();
                    System.out.println();

                    userShapes.add(new Rect(x, y, h, w));
                }
                else if (shapeOption == 5) {
                    double x;
                    double y;
                    double s;

                    System.out.print("Please enter a value for the square's x-coordinate: ");
                    x = reader.nextDouble();
                    System.out.println();

                    System.out.print("Please enter a value for the square's y-coordinate: ");
                    y = reader.nextDouble();
                    System.out.println();

                    System.out.print("Please enter a value for the square's length: ");
                    s = reader.nextDouble();
                    System.out.println();

                    userShapes.add(new Square(x, y, s));
                }
                else if (shapeOption == 6) {
                    double x;
                    double y;
                    double l;
                    double a;
                    double s;

                    System.out.print("Please enter a value for the N-Gon's x-coordinate: ");
                    x = reader.nextDouble();
                    System.out.println();

                    System.out.print("Please enter a value for the N-Gon's y-coordinate: ");
                    y = reader.nextDouble();
                    System.out.println();

                    System.out.print("Please enter a value for the N-Gon's side length: ");
                    l = reader.nextDouble();
                    System.out.println();

                    System.out.print("Please enter a value for the N-Gon's apothem length: ");
                    a = reader.nextDouble();
                    System.out.println();

                    System.out.print("Please enter a value for the N-Gon's number of sides: ");
                    s = reader.nextDouble();
                    System.out.println();

                    userShapes.add(new NGon(x, y, l, a, s));
                }
            }
            else if (option == 2) {
                if (userShapes.size() >= 1) {
                    System.out.print("Please choose an option by typing the option number: \n1. Standard Pen \n2. Wiggle Pen \n3. Rainbow Pen \n4. Wiggle Rainbow Pen \n5. Slow Pen \n");
                    int penOption = reader.nextInt();
                    System.out.println();

                    if (penOption == 1) {
                        StandardPen sp = new StandardPen();
                        for (Shape us: userShapes) {
                            us.draw(sp);
                            System.out.println(us);
                        }
                    }
                    else if (penOption == 2) {
                        WigglePen wp = new WigglePen();
                        for (Shape us: userShapes) {
                            us.draw(wp);
                            System.out.println(us);
                        }
                    }
                    else if (penOption == 3) {
                        RainbowPen rp = new RainbowPen();
                        for (Shape us: userShapes) {
                            us.draw(rp);
                            System.out.println(us);
                        }
                    }
                    else if (penOption == 4) {
                        WiggleRainbowPen wrp = new WiggleRainbowPen();
                        for (Shape us: userShapes) {
                            us.draw(wrp);
                            System.out.println(us);
                        }
                    }
                    else if (penOption == 5) {
                        System.out.print("Please enter a value for the Slow Pen's delay: ");
                        int delay = reader.nextInt();
                        System.out.println();

                        SlowPen slp = new SlowPen(delay);

                        for (Shape us: userShapes) {
                            us.draw(slp);
                            System.out.println(us);
                        }
                    }
                }
                else {
                    System.out.println("Please add a shape.");
                }
            }

            System.out.print("Please choose an option by typing the option number: \n1. Add a Shape \n2. Draw \n9. Quit \n");
            option = reader.nextInt ();
            System.out.println();
        }

        System.out.println("Thank you!");
    }
}
