package apcs.turtles;

import TurtleGraphics.Pen;

public class Circle implements Shape, Comparable<Circle>{
    protected double xPos;
    protected double yPos;
    protected double radius;

    public Circle() {
        xPos = 0;
        yPos = 0;
        radius = 1;
    }

    public Circle(double x, double y, double r) {
        xPos = x;
        yPos = y;
        radius = r;
    }

    @Override
    public double getXPos() {
        return this.xPos;
    }

    @Override
    public double getYPos() {
        return this.yPos;
    }

    @Override
    public void move(double xPos, double yPos) {
        this.xPos = xPos;
        this.yPos = yPos;
    }

    @Override
    public void stretchBy(double factor) {
        this.radius = this.radius * factor;
    }

    @Override
    public double area() {
        return (Math.PI * (Math.pow(this.radius, 2)));
    }

    @Override
    public void draw(Pen p) {
        p.up();
        p.move(this.xPos + this.radius, this.yPos);
        p.setDirection(90);
        p.down();
        double circumference = 2 * Math.PI * this.radius;

        for (int i = 0; i < 360; i++) {
            p.move(circumference/360);
            p.turn(1);
        }
    }

    public String toString() {
        return ("Circle: center = (" + this.xPos + ", " + this.yPos + "); radius = " + this.radius);
    }

    @Override
    public int compareTo(Circle o) {
        if (this.area() - o.area() > -1 && this.area() - o.area() < 0) {
            return -1;
        }
        else if (this.area() - o.area() > 0 && this.area() - o.area() < 1) {
            return 1;
        }
        return (int)(this.area() - o.area());
    }
}
