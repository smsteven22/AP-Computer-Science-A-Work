package apcs.turtles;

import TurtleGraphics.SketchPadWindow;

public class KochRunner {
    public static void main(String[] args) {
        SketchPadWindow sk = new SketchPadWindow(500, 500);
        SlowPen p = new SlowPen (sk, 100);
        double length = 400;
        int degree = 0;

        drawKochCurve(p, length, degree);

        SketchPadWindow sk2 = new SketchPadWindow(500, 500);
        SlowPen p2 = new SlowPen(sk2, 100);
        drawKochCurve(p2, length, degree + 3);

        SketchPadWindow sk3 = new SketchPadWindow(100000, 100000);
        SlowPen p3 = new SlowPen(sk3, 100);
        p3.up();
        p3.move(0,0);
        p3.move(-1*(length/2), 0.58*(length));
        p3.setDirection(0);
        p3.down();
        drawKochCurve(p3, length, degree+4);
        p3.turn(-120);
        drawKochCurve(p3, length, degree+4);
        p3.turn(-120);
        drawKochCurve(p3, length, degree+4);

        SketchPadWindow sk4= new SketchPadWindow(500, 500);
        SlowPen p4 = new SlowPen(sk4, 100);
        drawDragonCurve(p4, 10, 10);
    }

    public static void drawKochCurve(SlowPen p, double length, int degree) {
        if (degree == 0) {
            p.move(length);
        }
        else {
            drawKochCurve(p, length/3, degree-1);
            p.turn(60);
            drawKochCurve(p, length/3, degree-1);
            p.turn(-120);
            drawKochCurve(p, length/3, degree-1);
            p.turn(60);
            drawKochCurve(p, length/3, degree-1);
        }
    }

    public static void drawDragonCurve(SlowPen p, double length, int degree) {
        if (degree == 0) {
            p.move(length);
        }
        else {
            drawDragonCurve(p, length, degree-1);
            p.turn(90);
            drawDragonCurve2(p, length, degree-1);
        }
    }

    public static void drawDragonCurve2(SlowPen p, double length, int degree) {
        if (degree == 0) {
            p.move(length);
        }
        else {
            drawDragonCurve(p, length, degree - 1);
            p.turn(-90);
            drawDragonCurve2(p, length, degree-1);
        }
    }
}
