/*
    I completed an extension: I incorporated multiple functionalities, including user-input for maximum amount of
    points, user-input for the number of test scores to be graded, added helper methods for prompting the user (one
    method for doubles and integers (casting), and one method for Strings), and an optional percent calculator method.
    The percent method takes a double amount of points and an array of scores as parameters, and makes a copy of the
    array to perform calculations on. Then, the method utilizes a for loop to loop through every array value to calculate
    the percent by dividing the score by the max number of points passed as a parameter, then multiplies by 100 to find
    the percent. The method then returns the edited array copy containing the score percentages.

    These extensions demonstrate mastery because it highlights my understanding of using arrays. For example, I know
    that arrays can only be one set size, leading to the user-input piece. So the user can ensure they have enough
    space for all of their scores, the program prompts the user for the number of scores they wish to report and then
    uses this number to create the array size. On top of the user-input for the array size, the program also utilizes
    user input for the maximum number of points on the test, and adjusts the range of points to be that value in the
    error checking section of the program, to ensure that the user does not enter a score that is out of their custom
    range. In addition, the prompt and promptString methods demonstrates mastery of how helper methods can make
    object-oriented programming in Java easier and less messy within the runner. To avoid having to write the same
    print and reader statements over and over again, the prompt method reduces this to one repeated line for doubles
    and ints (by casting), and the promptString method reduces this to one repeated line for Strings (because Strings
    cannot be converted to doubles or ints through casting). Finally, the percent method demonstrates my understanding of
    how arrays can be modified. In order to return a new array containing the calculated percentages, a copy of the
    passed array must be made to perform calculations on, because editing arrays passed as parameters also edits the
    original array.
 */

package apcs.grades;

import java.util.Arrays;
import java.util.Scanner;

public class Runner {
    public static void main(String[] args) {
        Scanner reader = new Scanner (System.in);
        double points = prompt("Enter a maximum number of points available (max score): ", reader);
        int number = (int)prompt("Enter a number of test scores to be graded: ", reader);
        double[] scores = new double[number];
        int count = 0;
        while (count < number) {
            try {
                double input = prompt("Enter a test score: ", reader);
                if (input >= 0 && input <= points) {
                    scores[count] = input;
                    count++;
                }
                else {
                    System.out.println("That score is not within the range of 0.0 to " + points + " points.");
                }
            }
            catch (Exception except) {
                System.out.println("That is not a valid score. Please try again.");
                reader.nextLine();
            }
        }

        String ans = stringPrompt("Would you like to calculate the score percentages (Y or N)?", reader);

        System.out.println("Scores: " + Arrays.toString(scores));
        System.out.println("The maximum score is: " + max(scores) + " points.");
        System.out.println("The minimum score is: " + min(scores) + " points.");
        System.out.println("The mean score is: " + mean(scores) + " points.");
        System.out.println("The median score is: " + median(scores) + " points.");
        if (ans.equals("Y")) {
            double[] percentage = percent(scores, points);
            System.out.println("Percentages: " + Arrays.toString(percentage));
        }
    }

    public static double prompt(String question, Scanner reader) {
        System.out.print(question);
        double ans = reader.nextDouble();
        return ans;
    }

    public static String stringPrompt(String question, Scanner reader) {
        System.out.print(question);
        String ans = reader.next();
        return ans;
    }

    public static double min (double[] arr) {
        double minimum = arr[0];
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] < minimum) {
                minimum = arr[i];
            }
        }
        return minimum;
    }

    public static double max (double[] arr) {
        double maximum = arr[0];
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] > maximum) {
                maximum = arr[i];
            }
        }
        return maximum;
    }

    public static double mean (double[] arr) {
        double mean = 0.0;
        for (int i = 0; i < arr.length; i++) {
            mean += arr[i];
        }
        mean /= (double)arr.length;
        return mean;
    }

    public static double median (double[] arr) {
        double[] copy = Arrays.copyOf(arr, arr.length);
        Arrays.sort(copy);
        int half = arr.length / 2;
        double median = arr[half];
        return median;
    }

    public static double[] percent (double[] arr, double points) {
        double[] copy = Arrays.copyOf(arr, arr.length);
        for (int i = 0; i < arr.length; i++) {
            copy[i] = (arr[i] / points) * 100.0;
        }
        return copy;
    }
}
