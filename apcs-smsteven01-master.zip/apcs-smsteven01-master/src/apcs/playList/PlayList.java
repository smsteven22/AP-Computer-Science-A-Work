package apcs.playList;

import java.util.ArrayList;

/*
I completed an extension: The added Shuffle method takes the playlist Array List and randomizes the order in which each
song is played. The method uses a variety of techniques, including an additional Array List, for and while loops, if
statements, and various Array List methods to play each song in the user's playlist once in a random order.  First, the
method creates a new Array List to store the mixed indexes of the songs in the playlist. An Array List is used instead
of an array because an Array List can be added to and does not have a fixed size. After the Array List is created, the
first randomized index is added so that the Array List has some contents for the for and while loops. The method then
begins a for loop to ensure there is an index value included on the track ArrayList for each song in the user's playlist.
Within the first for loop there is a while loop that continues to create new randomized index values until either a new
random value is created or the indexing through the while loop reaches the maximum index of the track Array List. The
max index of the Array List is included as a condition to ensure that no Index Out of Bounds Errors are thrown. After an
add value satisfies these conditions, or the max index value of track is reached, the while loop concludes and continues
onto a set of if-else statements to check if the while loop ended before a new randomized index value was created. The
check to the previous add value is included because there is a chance for the randomized value to equal the previous
value due to the max index condition in the while loop, resulting in a repeated song index, therefore not completely
shuffling the user's playlist. If either condition is met to void the add value, a new randomized add value is created
and the tracking number for the for loop is subtracted by 1 so the for loop completes another loop for the same i value.
If none of the conditions are met, then the new index value is added to the track Array List and the for loop is
repeated for another index value. Once the first for loop is completed, a second for loop is initiated that parses
through the track Array List containing the shuffled indexes for the user's playlist, extracts these values from the
track Array List, and plays the song corresponding to that index from the user's playlist.

In addition to the added shuffle method, incorporating a Spotify Web API into this project was also considered for an
extension. Work was completed in the PlayListExtension java class until it was realized that due to the way the Peak to
Peak AP Computer Science class programs on IntelliJ instead of a web server, the Web API extension was not easily
achieved.

This extension demonstrates mastery because it exhibits not only a deep understanding of how to use Array Lists, but
also my curiosity, drive, and perserverance through challenging coding problems. This extension uses multiple ways to
traverse through Array Lists along with a deeper understanding of indexing, creating, and adding items within an Array
List. In addition, each extension idea highlights my passion and drive to excel in Computer Science. I was really
excited about incorporating the Spotify Web API extension, even though it ended up not working, because it was something
new to learn and apply what I know about Array Lists and Java programming to a real-world application. Both extension
ideas also exhibit my grit and perserverance through errors in code and ideas not quite working as I'd hoped. Instead of
giving up after learning that the web api could not easily be incorporated, I put my head down and got to work on
another extension with the same passion and interest. While I thought the shuffle method was going to be simple, I still
encountered numerous bugs and errors when running my ideas. Through using the coverage runner feature in IntelliJ, I was
able to figure out and troublesoot where my code wasn't being run and thrown errors. In order to fix these bugs, I had
to creatively think about and visualize how Array Lists work (like the .size()-1 is the max index), and incorporate many
different ideas into a final product.
 */

public class PlayList {
    private ArrayList<Song> songList;

    public PlayList() {
        this.songList = new ArrayList<Song>();
    }

    public void add(String name) {
        Song addSong = new Song(name);
        this.songList.add(addSong);
    }

    public int size() {
        return this.songList.size();
    }

    public String getSongName(int index) {
        if (index > this.songList.size() - 1) {
            throw new IndexOutOfBoundsException("The requested index does not fit in your playlist! Please try again.");
        }
        Song song = this.songList.get(index);
        return song.getName();
    }

    public void play(int index) {
        if (index > this.songList.size() - 1) {
            throw new IndexOutOfBoundsException("The requested index does not fit in your playlist! Please try again.");
        }
        Song song = this.songList.get(index);
        System.out.println("Now playing: " + song.toString());
        int plays = song.getPlays();
        plays++;
        song.setPlays(plays);
    }

    public void play() {
        for (int i = 0; i < this.songList.size(); i++) {
            this.play(i);
        }
    }

    public void remove(int index) {
        if (index > this.songList.size() - 1) {
            throw new IndexOutOfBoundsException("The requested index does not fit in your playlist! Please try again.");
        }
        this.songList.remove(index);
    }

    public void insert(int index, String songName) {
        if (index > this.songList.size()) {
            throw new IndexOutOfBoundsException("The requested index does not fit in your playlist! Please try again.");
        }
        Song addSong = new Song(songName);
        this.songList.add(index, addSong);
    }

    public void move(int fromIndex, int toIndex) {
        if (fromIndex < 0 || fromIndex > this.songList.size() || toIndex < 0 || toIndex > this.songList.size()) {
            throw new IndexOutOfBoundsException("The requested index does not fit in your playlist! Please try again.");
        }
        Song moveSong = this.songList.get(fromIndex);
        this.songList.add(toIndex, moveSong);
        this.songList.remove(fromIndex);
    }

    public int find(String songName) {
        int index = -1;
        for (int i = 0; i < this.songList.size(); i++) {
            Song findSong = this.songList.get(i);
            if (findSong.getName().equals(songName)) {
                index = i;
            }
        }
        return index;
    }

    public ArrayList<Song> getMostPlayed() {
        if (this.songList.size() == 0) {
            throw new IllegalStateException("Your playlist has no songs!");
        }
        int maxPlays = 0;
        for (int i = 0; i < this.songList.size(); i++) {
            Song favSong = this.songList.get(i);
            if (favSong.getPlays() > maxPlays) {
                maxPlays = favSong.getPlays();
            }
        }
        ArrayList<Song> favorites = new ArrayList<Song>();
        for (int i = 0; i < this.songList.size(); i++) {
            Song maxSong = this.songList.get(i);
            if (maxSong.getPlays() == maxPlays) {
                favorites.add(this.songList.get(i));
            }
        }
        return favorites;
    }

    public void rate(int index, int rating) {
        if (index > this.songList.size() || index < 0) {
            throw new RuntimeException("The requested index does not fit in your playlist! Please try again.");
        } else if (rating > 5 || rating < 1) {
            throw new RuntimeException("The rating is not within the 1-5 range. Please try again");
        }
        Song rateSong = this.songList.get(index);
        rateSong.setRating(rating);
    }

    public ArrayList<Song> getFavorite() {
        if (this.songList.size() == 0) {
            throw new IllegalStateException("Your playlist has no songs!");
        }
        int maxRating = 0;
        for (int i = 0; i < this.songList.size(); i++) {
            Song favSong = this.songList.get(i);
            if (favSong.getRating() > maxRating) {
                maxRating = favSong.getRating();
            }
        }
        ArrayList<Song> favorites = new ArrayList<Song>();
        for (int i = 0; i < this.songList.size(); i++) {
            Song maxSong = this.songList.get(i);
            if (maxSong.getRating() == maxRating) {
                favorites.add(this.songList.get(i));
            }
        }
        return favorites;
    }

    // Start of Extension
    public void shuffle() {
        ArrayList<Integer> track = new ArrayList<Integer>(this.songList.size());

        int add = (int)(Math.random() * this.songList.size());
        int trackIndex = 0;
        int prevAdd = add;

        track.add(0, add);

        for (int i = 1; i < this.songList.size(); i++) {
            add = (int)(Math.random() * this.songList.size());

            while (add != track.get(trackIndex) && trackIndex < track.size()-1) {
                trackIndex++;
            }

            if (trackIndex < track.size()-1 || prevAdd == add) {
                add = (int)(Math.random() * this.songList.size());
                i = i-1;
            }
            else {
                track.add(i, add);
                prevAdd = add;
            }

            trackIndex = 0;
        }

        for (int i = 0; i < track.size(); i++) {
            int index = track.get(i);
            this.play(index);
        }
    }
    // End of Extension

    public String toString() {
        return songList.toString();
    }
}
