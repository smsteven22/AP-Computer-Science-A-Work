package apcs.playList;

public class Song {
    private String songName;
    private int plays;
    private int rating;

    public Song(String name) {
        this.songName = name;
        this.plays = 0;
        this.rating = 0;
    }

    public String getName() {
        return this.songName;
    }

    public int getPlays() {
        return this.plays;
    }

    public int getRating() {
        return this.rating;
    }

    public void setName(String name) {
        this.songName = name;
    }

    public void setPlays(int num) {
        this.plays = num;
    }

    public void setRating(int rate) {
        this.rating = rate;
    }

    public String toString() {
        if (this.rating == 0) {
            return "Title: " + this.songName + "; Plays: " + this.plays + "; Rating: Not Rated";
        }
        return "Title: " + this.songName + "; Plays: " + this.plays + "; Rating: " + this.rating;
    }
}
