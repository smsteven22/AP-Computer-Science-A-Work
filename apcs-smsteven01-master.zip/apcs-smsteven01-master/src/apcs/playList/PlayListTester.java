package apcs.playList;

public class PlayListTester {
    public static void main (String [] argv) {
        // Extension idea: https://github.com/spotify-web-api-java/spotify-web-api-java

        PlayList aList = new PlayList();
        System.out.println ("Initial (empty) List is:\n" + aList);

        System.out.println ("\nTesting add and toString");
        System.out.println ("Adding The Final Countdown");
        aList.add ("The Final Countdown");
        System.out.println ("Adding Livin' on a Prayer");
        aList.add ("Livin' on a Prayer");
        System.out.println ("Adding No Time to Die");
        aList.add("No Time to Die");
        System.out.println ("Adding Si Te Atreves A Sonar");
        aList.add("Si Te Atreves A Sonar");
        System.out.println ("Adding Centuries");
        aList.add("Centuries");
        System.out.println ("Adding Shallow");
        aList.add("Shallow");
        System.out.println ("Adding All of Me");
        aList.add("All of Me");
        System.out.println ("Adding If I Were a Boy");
        aList.add("If I Were a Boy");
        System.out.println ("Adding Beautiful");
        aList.add("Beautiful");
        System.out.println ("Adding What a Wonderful World");
        aList.add("What a Wonderful World");
        System.out.println ("Adding Dreamsicle");
        aList.add("Dreamsicle");
        System.out.println ("Adding The Incredibles Suite");
        aList.add("The Incredibles Suite");
        System.out.println ("Adding Into the Unknown");
        aList.add("Into the Unknown");
        System.out.println ("Adding 867-5309 / Jenny");
        aList.add("867-5309 / Jenny");
        System.out.println ("Adding Brick House");
        aList.add("Brick House");
        System.out.println ("Adding Million Reasons");
        aList.add("Million Reasons");
        System.out.println ("Adding Bohemian Rhapsody");
        aList.add("Bohemian Rhapsody");
        System.out.println ("Adding Piano Man");
        aList.add("Piano Man");
        System.out.println ("Adding Faithfully");
        aList.add("Faithfully");
        System.out.println ("Adding Landini");
        aList.add("Landini");
        System.out.println ("Adding Birdland");
        aList.add("Birdland");
        System.out.println ("Adding If I had $1,000,000");
        aList.add("If I had $1,000,000");
        System.out.println ("Adding Show Yourself");
        aList.add("Show Yourself");
        System.out.println ("Adding The Hanging Tree");
        aList.add("The Hanging Tree");
        System.out.println ("Adding abcdedfu (angrier)");
        aList.add("abcdefu (angrier)");
        System.out.println ("List is:\n" + aList);

        System.out.println("\nTesting getSongName method: ");
        try {
            String ex1 = aList.getSongName(0);
            System.out.println(ex1);
            String ex2 = aList.getSongName(2);
            System.out.println(ex2);
        } catch (Exception e) {
            System.out.println("Error: ");
            e.printStackTrace();
        }


        System.out.println("\nTesting play method:");
        try{
            aList.play(1);
            System.out.println(aList);
            aList.play(2);
            System.out.println(aList);
        } catch (Exception e) {
            System.out.println("Error: ");
            e.printStackTrace();
        }


        System.out.println("\nTesting overloaded play method:");
        try {
            aList.play();
            System.out.println(aList);
        } catch (Exception e) {
            System.out.println("Error: ");
            e.printStackTrace();
        }

        System.out.println("\nTesting remove method:");
        try {
            aList.remove(0);
            System.out.println(aList);
            aList.remove(1);
            System.out.println(aList);
        } catch (Exception e) {
            System.out.println("Error: ");
            e.printStackTrace();
        }


        System.out.println("\nTesting insert method:");
        try {
            aList.insert(0, "My Minecraft Girlfriend Broke Up with Me");
            System.out.println(aList);
            aList.insert(2, "Easy on Me");
            System.out.println(aList);
            aList.insert(4, "Bella's Lullaby");
            System.out.println(aList);
        } catch (Exception e) {
            System.out.println("Error: ");
            e.printStackTrace();
        }

        System.out.println("\nTesting move method:");
        try {
            aList.move(0, 3);
            System.out.println(aList);
            aList.move(3, 5);
            System.out.println(aList);
        } catch (Exception e) {
            System.out.println("Error: ");
            e.printStackTrace();
        }


        System.out.println("\nTesting find method:");
        try {
            System.out.println("Easy on Me:" + aList.find("Easy on Me"));
            System.out.println("The Planets, Op.32: IV. Jupiter, the Bringer of Jollity: " + aList.find("The Planets, Op.32: IV. Jupiter, the Bringer of Jollity"));
            System.out.println(aList);
        } catch (Exception e) {
            System.out.println("Error: ");
            e.printStackTrace();
        }


        System.out.println("\nTesting getMostPlayed method:");
        try {
            System.out.println(aList.getMostPlayed());
            System.out.println(aList);
        } catch (Exception e) {
            System.out.println("Error: ");
            e.printStackTrace();
        }

        System.out.println("\nTesting rate method:");
        try {
            aList.rate(2, 5);
            System.out.println(aList);
            aList.rate(4,3);
            System.out.println(aList);
            aList.rate(1, 7);
            System.out.println(aList);
        } catch (Exception e) {
            System.out.println("Error: ");
            e.printStackTrace();
        }


        System.out.println("\nTesting getFavorite method:");
        try {
            System.out.println(aList.getFavorite());
            System.out.println(aList);
        } catch (Exception e) {
            System.out.println("Error: ");
            e.printStackTrace();
        }

    }

}
