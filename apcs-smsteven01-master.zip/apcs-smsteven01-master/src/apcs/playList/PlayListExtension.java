package apcs.playList;
/*
import se.michaelthelin.spotify.SpotifyApi;
import se.michaelthelin.spotify.SpotifyHttpManager;
import se.michaelthelin.spotify.requests.authorization.authorization_code.AuthorizationCodeUriRequest;

import java.net.URI;

public class PlayListExtension extends PlayList {
    private static final String clientID = "be96243c079b40b3afd6ffc7e99e8838";
    private static final String clientSecret = "0d18fed185114897b8d757457e57f6a4";
    private static final URI redirectUri = SpotifyHttpManager.makeUri("https://smstevenAPCS.com/PlayList");

    private static final SpotifyApi spotifyApi = new SpotifyApi.Builder()
            .setClientId(clientID)
            .setClientSecret(clientSecret)
            .setRedirectUri(redirectUri)
            .build();
    private static final AuthorizationCodeUriRequest authorizationCodeUriRequest = spotifyApi.authorizationCodeUri()
            .build();

    public static void authorizationCodeUri_Sync() {
        final URI uri = authorizationCodeUriRequest.execute();

        System.out.println("URI: " + uri.toString());
    }

    public static void main(String[] args) {
        authorizationCodeUri_Sync();
    }
}
*/