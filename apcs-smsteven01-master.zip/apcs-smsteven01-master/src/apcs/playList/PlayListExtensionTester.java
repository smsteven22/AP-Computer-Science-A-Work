package apcs.playList;

public class PlayListExtensionTester {
    public static void main(String[] args) {
        PlayList aList = new PlayList();
        aList.add ("The Final Countdown");
        aList.add ("Livin' on a Prayer");
        aList.add("No Time to Die");
        aList.add("Si Te Atreves A Sonar");
        aList.add("Centuries");
        aList.add("Shallow");
        aList.add("All of Me");
        aList.add("If I Were a Boy");
        aList.add("Beautiful");
        aList.add("What a Wonderful World");
        aList.add("Dreamsicle");
        aList.add("The Incredibles Suite");
        aList.add("Into the Unknown");
        aList.add("867-5309 / Jenny");
        aList.add("Brick House");
        aList.add("Million Reasons");
        aList.add("Bohemian Rhapsody");
        aList.add("Piano Man");
        aList.add("Faithfully");
        aList.add("Landini");
        aList.add("Birdland");
        aList.add("If I had $1,000,000");
        aList.add("Show Yourself");
        aList.add("The Hanging Tree");
        aList.add("abcdefu (angrier)");
        System.out.println ("List is:\n" + aList);

        System.out.println("\nTesting shuffle extension method:");
        try {
            aList.shuffle();
            System.out.println(aList);
        } catch (Exception e) {
            System.out.println("Error: ");
            e.printStackTrace();
        }
    }
}
