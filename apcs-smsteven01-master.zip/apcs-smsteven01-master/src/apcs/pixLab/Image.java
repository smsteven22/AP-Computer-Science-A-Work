package apcs.pixLab;
/*
 I completed an extension: The added sharpen method takes the blurred picture and un-blurs the picture. The program uses
 multiple nested for-loops to traverse each section of the 2D array that the program is sharpening. First, the for-loops
 get the red, green, and blue values of the pixel occupying the 2D array index, and multiplies this value by 9 to ensure
 that an accurate value will be obtained as the neighboring pixels' red, green, and blue values are subtracted from the
 original pixel's red, green, and blue values. The second set of nested for-loops enables the method to access the red,
 green, and blue values of the original pixel's neighbors. After the second set of nested for-loops, the original pixel's
 red, green, and blue values are added back to the new value because it was taken out through the nested for-loops.
 After this calculation is complete, the method then checks if each new red, green, and/or blue values are within the
 rgb color range of 0 to 255. If the value is less than 0, then it is set to 0, and if the value is greater than 255,
 then it is set to 255. The new values are then added into a temporary 2D array storing the sharpened pixels and the
 first set of nested for-loops is repeated. After the entire picture has been looped through and the 2D array filled
 with the new pixel values, another set of nested for-loops is utilized to replace the current values of the picture's
 2D array with the sharpened values within the temporary 2D array, effectively re-sharpening the picture following the
 utilization of the blur method.

 This extension demonstrates mastery because it exhibits my ability to think through errors and reverse the blur effect
 implemented in the blur method. Within this extension, I ran into many bugs pertaining to index out of bounds errors
 and having the red, green, and/or blue values of the sharpened pixel be outside of the color range. Instead of giving
 up with this extension, I perservered through these challenges and critically thought about how to correcet them within
 the scope of re-sharpening a photo. In addition, through this extension, I had to think about how to effectively loop
 through sections of 2D arrays spanning across multiple rows and columns, and I had to figure out what indexes should be
 included to ensure that an index out of bounds error was not thrown while traversing the 2D array. This included using
 two sets of nested for-loops for each section of the 2D array: the 2D array as a whole as well as the immediate
 neighbor indexes to the pixel index concerned.

 Resources used: Mr. Hettmansperger ;)
 */

import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

public class Image {
    /*
     * Instance variables: image - a 2D Array of Colors
     */
    private Color[][] image;
    /**
     * Creates a new Image based on an existing 2D array of colors
     * @param image the array of Colors
     */
    public Image (Color[][] image) {
        this.image = image;
    }
    /**
     * Creates a new Image from an image stored in a file
     * @param file the name of the file to create the Image from
     */
    public Image (String file) {
        // read image and load into array of Colors
        try {
            BufferedImage img = ImageIO.read(new File(file));
            this.image = new Color[img.getHeight()][img.getWidth()];
            for (int r = 0; r < this.image.length; r++) {
                for (int c = 0; c < this.image[r].length; c++) {
                    this.image[r][c] = new Color(img.getRGB(c, r));
                }
            }
        } catch (IOException e) {  // couldn't open file
            e.printStackTrace();
            System.exit(-1);
        }
    }
    /**
     * Displays a COPY of the image into a Java GUI Window
     * @param title The title to be displayed in the window's title bar
     */
    public void display (String title) {
        new ImageGUI (this.image, title);
    }

    /**
     * copy - creates and returns a duplicate copy of an image
     *
     * precondition: the image has at least one row and at least one column
     *
     * @return a copy of the image
     */
    public Image copy () {
        Color[][] theCopy = new Color[this.image.length][this.image[0].length];
        for (int r=0; r<this.image.length; r++) {
            for (int c=0; c<this.image[0].length; c++) {
                theCopy[r][c] = new Color (this.image[r][c].getRGB ());
            }
        }
        return new Image (theCopy);
    }

    /**
     * removeBlue - modifies an image by removing the blue component form all pixels
     *
     * Postcondition: the image itself is modified
     */
    public void removeBlue() {

        // loop through all pixels
        for (int r = 0; r < this.image.length; r++) {
            for (int c = 0; c < this.image[r].length; c++) {

                // get component parts of pixel's color
                Color pixel = this.image[r][c];
                int red = pixel.getRed ();
                int green = pixel.getGreen ();
                int blue = pixel.getBlue ();

                // construct a new pixel with the same red and green but no blue
                this.image[r][c] = new Color (red, green, 0);
            }
        }
        return;
    }

    /**
     * removeRed - modifies an image by removing the red component form all pixels
     *
     * Postcondition: the image itself is modified
     */
    public void removeRed() {

        // loop through all pixels
        for (int r = 0; r < this.image.length; r++) {
            for (int c = 0; c < this.image[r].length; c++) {

                // get component parts of pixel's color
                Color pixel = this.image[r][c];
                int red = pixel.getRed();
                int green = pixel.getGreen();
                int blue = pixel.getBlue();

                // construct a new pixel with the same blue and green but no red
                this.image[r][c] = new Color(0, green, blue);
            }
        }
    }

    /**
     * removeGreen - modifies an image by removing the green component form all pixels
     *
     * Postcondition: the image itself is modified
     */
    public void removeGreen() {

        // loop through all pixels
        for (int r = 0; r < this.image.length; r++) {
            for (int c = 0; c < this.image[r].length; c++) {

                // get component parts of pixel's color
                Color pixel = this.image[r][c];
                int red = pixel.getRed ();
                int green = pixel.getGreen ();
                int blue = pixel.getBlue ();

                // construct a new pixel with the same red and blue but no green
                this.image[r][c] = new Color (red, 0, blue);
            }
        }
        return;
    }

    /**
     * blackWhite - modifies an image by changing the color to an average of red, green, and blue from all pixels
     *
     * Postcondition: the image itself is modified
     */
    public void blackWhite() {

        // loop through all pixels
        for (int r = 0; r < this.image.length; r++) {
            for (int c = 0; c < this.image[r].length; c++) {

                // get component parts of pixel's color
                Color pixel = this.image[r][c];
                int red = pixel.getRed ();
                int green = pixel.getGreen ();
                int blue = pixel.getBlue ();
                int average = (red+blue+green)/3;

                // construct a new pixel with the average of the red, green, and blue
                this.image[r][c] = new Color (average, average, average);
            }
        }
        return;
    }

    /**
     * invert - modifies an image by inverting the red, green, and blue values from all pixels
     *
     * Postcondition: the image itself is modified
     */
    public void invert() {

        // loop through all pixels
        for (int r = 0; r < this.image.length; r++) {
            for (int c = 0; c < this.image[r].length; c++) {

                // get component parts of pixel's color
                Color pixel = this.image[r][c];
                int red = pixel.getRed ();
                int green = pixel.getGreen ();
                int blue = pixel.getBlue ();

                // construct a new pixel with the same red and blue but no green
                this.image[r][c] = new Color (255-red, 255-green, 255-blue);
            }
        }
        return;
    }

    /**
     * removeGreen - modifies an image by mirroring a picture around the midpoint.
     *
     * Postcondition: the image itself is modified
     */
    public void mirrorVertical() {

        // loop through all pixels
        for (int r = 0; r < this.image.length/2; r++) {
            for (int c = 0; c < this.image[r].length; c++) {

                // get component parts of pixel's color
                Color pixel = this.image[r][c];
                int red = pixel.getRed ();
                int green = pixel.getGreen ();
                int blue = pixel.getBlue ();

                // construct a new pixel with the same red and blue but no green
                this.image[(this.image.length-1)-r][c] = new Color (red, green, blue);
            }
        }
        return;
    }

    /**
     * flipHorizontal - modifies an image by reversing the image over the y-axis.
     *
     * Postcondition: the image itself is modified
     */
    public void flipHorizontal() {
        Color[][] tempImage = new Color[this.image.length][this.image[0].length/2];
        for (int r = 0; r < this.image.length; r++) {
            for (int c = 0; c < this.image[r].length/2; c++) {
                Color pixel = this.image[r][c];
                int red = pixel.getRed();
                int green = pixel.getGreen();
                int blue = pixel.getBlue();

                tempImage[r][c] = new Color (red, green, blue);
            }
        }

        for (int r = 0; r < this.image.length; r++) {
            for (int c = 0; c < this.image[r].length/2; c++) {
                Color pixel = this.image[r][(this.image[r].length-1)-c];
                int red = pixel.getRed();
                int green = pixel.getGreen();
                int blue = pixel.getBlue();

                this.image[r][c] = new Color (red, green, blue);
                this.image[r][(this.image[r].length-1)-c] = tempImage[r][c];
            }
        }
        return;
    }

    public void blur() {
        Color[][] tempImage = new Color[image.length][image[0].length];
        int redSum = 0;
        int greenSum = 0;
        int blueSum = 0;
        int count = 0;

        for (int r = 1; r < this.image.length-1; r++) {
            for (int c = 1; c < this.image[r].length-1; c++) {
                    for (int r2 = r - 1; r2 <= r + 1; r2++) {
                        for (int c2 = c - 1; c2 <= c + 1; c2++) {
                            Color pixel = this.image[r2][c2];
                            int red2 = pixel.getRed();
                            redSum = redSum+red2;
                            int green2 = pixel.getGreen();
                            greenSum = greenSum+green2;
                            int blue2 = pixel.getBlue();
                            blueSum = blueSum+blue2;
                            count++;
                        }
                    }
                int redAvg = redSum/count;
                int greenAvg = greenSum/count;
                int blueAvg = blueSum/count;
                tempImage[r][c] = new Color(redAvg, greenAvg, blueAvg);

                redSum = 0;
                greenSum = 0;
                blueSum = 0;
                count = 0;
            }
        }

        for (int r = 0; r < this.image.length; r++) {
            for (int c = 0; c < this.image[r].length; c++) {
                if (tempImage[r][c] != null) {
                    this.image[r][c] = tempImage[r][c];
                }
            }
        }
    }

    // Extension method below:
    public void sharpen() {
        Color[][] tempImage = new Color[image.length][image[0].length];
        int redNew = 0;
        int greenNew = 0;
        int blueNew = 0;

        for (int r = 1; r < this.image.length-1; r++) {
            for (int c = 1; c < this.image[r].length-1; c++) {
                Color pixel = this.image[r][c];
                int red = pixel.getRed();
                int green = pixel.getGreen();
                int blue = pixel.getBlue();
                redNew = red * 9;
                greenNew = green * 9;
                blueNew = blue * 9;

                for (int r2 = r - 1; r2 <= r + 1; r2++) {
                    for (int c2 = c - 1; c2 <= c + 1; c2++) {
                        Color pixel2 = this.image[r2][c2];
                        int red2 = pixel.getRed();
                        redNew -= red2;
                        int green2 = pixel2.getGreen();
                        greenNew -= green2;
                        int blue2 = pixel2.getBlue();
                        blueNew -= blue2;
                    }
                }

                redNew += red;
                greenNew += green;
                blueNew += blue;

                if (redNew < 0) {
                    redNew = 0;
                }
                if (redNew > 255) {
                    redNew = 255;
                }
                if (greenNew < 0) {
                    greenNew = 0;
                }
                if (greenNew > 255) {
                    greenNew = 255;
                }
                if (blueNew < 0) {
                    blueNew = 0;
                }
                if (blueNew > 255) {
                    blueNew = 255;
                }

                tempImage[r][c] = new Color(redNew, greenNew, blueNew);
            }
        }

        for (int r = 0; r < this.image.length; r++) {
            for (int c = 0; c < this.image[r].length; c++) {
                if (tempImage[r][c] != null) {
                    this.image[r][c] = tempImage[r][c];
                }
            }
        }
    }
}

