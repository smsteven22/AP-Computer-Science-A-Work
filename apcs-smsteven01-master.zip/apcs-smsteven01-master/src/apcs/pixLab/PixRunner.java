package apcs.pixLab;

import java.awt.Color;

public class PixRunner {

    public static void main(String[] args) {
        Color[][] img = new Color[256][256];
        for (int r = 0; r < img.length; r++) {
            for (int c = 0; c < img[r].length; c++) {
                img[r][c] = new Color(r, c, 255 - (r + c) / 2);
            }
        }
        Image a = new Image(img);
        a.display("Color Image");

        Image b = new Image("BobRossHintofSpringtime.jpg");
        b.display("Bob Ross' \"Hint of Springtime\"");

        Image c = b.copy();
        c.removeBlue();
        c.display("Bob Ross' \"Hint of Springtime\" without blue");

        Image d = b.copy();
        d.removeRed();
        d.display("Bob Ross' \"Hint of Springtime\" without red");

        Image e = b.copy();
        e.removeGreen();
        e.display("Bob Ross' \"Hint of Springtime\" without green");

        Image f = b.copy();
        f.blackWhite();
        f.display("Bob Ross' \"Hint of Springtime\" with an average color");

        Image g = b.copy();
        g.invert();
        g.display("Bob Ross' \"Hint of Springtime\" with an inverted color");

        Image h = b.copy();
        h.mirrorVertical();
        h.display("Bob Ross' \"Hint of Springtime\" mirrored over the x-axis");

        Image i = b.copy();
        i.flipHorizontal();
        i.display("Bob Ross' \"Hint of Springtime\" mirrored over the y-axis.");

        Image j = b.copy();
        j.blur();
        j.display("Bob Ross' \"Hint of Springtime\" blurred.");

        // Extension implementation below:
        Image k = b.copy();
        k.blur();
        k.sharpen();
        k.display("Bob Ross' \"Hint of Springtime\" sharpened.");
    }

}

