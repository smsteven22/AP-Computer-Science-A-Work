package apcs.guess;

/*
    I completed an extension: I created a third constructor that allows the user to add a custom range for guessing. I
    also included a part of the extension in the runner to determine how to proceed based on the user's responses. I
    was able to complete only a very simple, green extension due to class time constraints.

    This extension demonstrates mastery because it exhibits my understanding of object oriented programming in Java, how
    to use if/else statements with scanners, and scope levels. The runner includes a user prompt if they would like to
    use their own custom range, followed by a scanner to retrieve user input. The program then launches into if/else
    statements based on the user's answer. If the user would like to use a custom range, then the program prompts the
    user to enter their lower and upper bounds, collecting those values in between prompts (something that I learned
    from my internship at NASA -- make sure to collect the responses before asking for another one. This eliminates the
    error of placing the second desired value into the first variable). The program then constructs a new Value
    instance and continues to the rest of the program. If the user does not want to use a custom range, then the
    program constructs a default Value instance and continues to the rest of the program. I realized that I had to
    define the Value variable outside of the if/else statement to ensure the level scope was within the GuessRunner
    class and was available to future loops and uses. This realization demonstrates my understanding of scope because
    if I were to define and instantiate the Value instance within the if/else statements, I would not have been able to
    access these instances later in the program when they are actually used for the program's purpose.
 */
public class Value {
    private int value;

    public Value () {
        this.value = (int)(Math.random() * 101 + 1);
    }

    public Value (int userValue) {
        this.value = userValue;
    }

    // Beginning of custom range extension:
    public Value (int userLower, int userUpper) {
        this.value = (int)((Math.random() * (userUpper + 1)) + userLower);
    }
    // End of custom range extension.

    public int getValue () {
        return this.value;
    }

    public void setValue(int userNumber) {
        this.value = userNumber;
    }

    public boolean equals(Value secondValue) {
        if (this.value == secondValue.getValue()) {
            return true;
        }
        else {
            return false;
        }
    }


    public String toString () {
        String valueString = "Value: " + this.value;
        return valueString;
    }
}
