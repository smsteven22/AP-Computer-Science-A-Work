package apcs.guess;

import java.util.Scanner;

public class GuessRunner {
    public static void main(String[] args) {
        Value computerValue;
        Scanner reader = new Scanner(System.in);

        System.out.println("Welcome to the number guessing game! \nThe computer randomly generates a number between 1 and 100 (inclusive), and your task is to figure out the correct number. \nGood luck!");

        // Beginning of custom range extension:
        System.out.print("Would you like to use a custom range(Y or N)? ");
        String userAnswer = reader.nextLine();
        if (userAnswer.equals("Y")){
            System.out.print("Lower bound: ");
            int lower = reader.nextInt();
            System.out.print("Lower bound: ");
            int upper = reader.nextInt();
            computerValue = new Value(lower, upper);
            System.out.println("[Temporary print: " + computerValue.toString() + "]");
        }
        else {
            computerValue = new Value();
            System.out.println("[Temporary print: " + computerValue.toString() + "]");
        }
        // End of custom range extension.

        System.out.print("Enter an integer: ");
        int userNumber;
        boolean answerCheck = false;
        int count = 1;
        while (answerCheck == false) {
            try {
                userNumber = reader.nextInt();
                Value userValue = new Value(userNumber);
                if (computerValue.equals(userValue)) {
                    System.out.println("That's correct! You took " + count + " guess(es) to figure it out!");
                    answerCheck = true;
                    System.out.println("Thank you for playing!");
                } else if (userValue.getValue() > computerValue.getValue()) {
                    System.out.println("Your guess is too high! That's " + count + " guess(es).");
                    count++;

                    System.out.print("Please enter a new integer: ");
                } else {
                    System.out.println("Your guess is too low! That's " + count + " guess(es).");
                    count++;

                    System.out.print("Please enter a new integer: ");
                }
            } catch (Exception except) {
                System.out.print("That is not an integer. Please insert a new integer: ");
                reader.next();
            }
        }
    }
}
