package apcs.cockroach;

/*
I completed an extension: The added Location loc static variable in the CockroachWorld class creates a variable
that is part of every instance of CockroachWorld. This variable, loc, is used to randomize the corner that
the Cockroach instances will move to in the case that the lights are "on" and they are "hiding". In this class,
the variable loc is randomly changed to one of the four corners [(0,0) --> North West, (0, gr.getNumCols()-1) -->
North East, (gr.getNumRows()-1, 0) --> South West, or (gr.getNumRows()-1, gr.getNumCols()-1) --> South East]
whenever any key is pressed. The new Location is then called upon within the hide method of the Cockroach class
as the new target location for the Cockroach instances.

This extension demonstrates mastery because it exhibits my understanding of static methods and variables. Through
this extension, I was able to utilize my newfound knowledge of static methods and variables and my knowledge
of GridWorld to effectively change the target location and call this new location using the correct structure
of CockroachWorld.getLoc(). In addition, I was able to identify that CockroachWorld extends ActorWorld, which
enables the ability to call the getGrid method, which allows the Location static variable loc to change to
each of the index values of the 4 grid corners.
 */

import info.gridworld.actor.Actor;
import info.gridworld.actor.ActorWorld;
import info.gridworld.grid.Grid;
import info.gridworld.grid.Location;

public class CockroachWorld extends ActorWorld {
    private static boolean lightsOff = true;

    // Randomized corner extension static variable below:
    private static Location loc = new Location (0, 0);

    public CockroachWorld (Grid<Actor> grid) {
        super(grid);
        this.setMessage("Welcome to CockroachWorld!");
    }

    public static boolean getLightsOff() {
        return CockroachWorld.lightsOff;
    }

    public static void setLightsOff (boolean lightsOff) {
        CockroachWorld.lightsOff = lightsOff;
    }

    public static Location getLoc() {
        return CockroachWorld.loc;
    }

    public static void setLoc (Location loc) {
        CockroachWorld.loc = loc;
    }

    public boolean keyPressed(String key, Location loc) {
        CockroachWorld.setLightsOff(!CockroachWorld.getLightsOff());

        // Randomized corner exention begins below:
        Grid gr = this.getGrid();
        int rand = (int)(Math.random() * 4 + 1);
        System.out.println("Randomized corner: " + rand);
        if (rand == 2) {
            CockroachWorld.loc = new Location (0, gr.getNumCols()-1);
        }
        else if (rand == 3) {
            CockroachWorld.loc = new Location(gr.getNumRows()-1, 0);
        }
        else if (rand == 4) {
            CockroachWorld.loc = new Location(gr.getNumRows()-1, gr.getNumCols()-1);
        }
        else {
            CockroachWorld.loc = new Location(0, 0);
        }
        // End of randomized corner exension.

        System.out.println("Key: " + key + " Location: " + loc + " LightsOff: " + CockroachWorld.lightsOff);
        if (CockroachWorld.getLightsOff()) {
            this.setMessage("The lights are off!");
        }
        else {
            this.setMessage("The lights are on!");
        }
        return true;
    }
}
