package apcs.cockroach;

import info.gridworld.actor.Actor;
import info.gridworld.grid.Grid;
import info.gridworld.grid.Location;

import java.awt.*;
import java.util.ArrayList;

public class Cockroach extends Actor {
    public Cockroach () {
        this.setColor (null);
        int rand = (int)(Math.random() * 8) * 45;
        this.setDirection(rand);
    }

    public void act() {
        if (CockroachWorld.getLightsOff()) {
            scatter();
        }
        else {
            hide();
        }
    }

    public void scatter() {
        Grid gr = this.getGrid();
        Location loc = this.getLocation();
        this.setColor(new Color (102, 51, 153));
        ArrayList<Location> emptyNeighbors = gr.getEmptyAdjacentLocations(loc);
        if (emptyNeighbors.size() == 0) {
            return;
        }
        else {
            int randNeighbor = (int)(Math.random() * emptyNeighbors.size());
            Location neighborLoc = emptyNeighbors.get(randNeighbor);
            int newDirection = loc.getDirectionToward(neighborLoc);
            this.setDirection(newDirection);
            this.moveTo(neighborLoc);
        }
        return;
    }

    public void hide() {
        this.setColor(new Color(255, 20, 147));
        Grid gr = this.getGrid();
        Location loc = this.getLocation();

        // Cockroach class implementation of randomized location:
        Location targetLoc = CockroachWorld.getLoc();

        int newDirection = loc.getDirectionToward(targetLoc);
        int newDirection2 = newDirection + 45;
        int newDirection3 = newDirection-45;
        int newDirection4 = newDirection+90;
        int newDirection5 = newDirection-90;

        Location adjacentLoc = loc.getAdjacentLocation(newDirection);
        Location adjacentLoc2 = loc.getAdjacentLocation(newDirection2);
        Location adjacentLoc3 = loc.getAdjacentLocation(newDirection3);
        Location adjacentLoc4 = loc.getAdjacentLocation(newDirection4);
        Location adjacentLoc5 = loc.getAdjacentLocation(newDirection5);

        if (gr.isValid(adjacentLoc) && gr.get(adjacentLoc) == null) {
            this.setDirection(newDirection);
            this.moveTo(adjacentLoc);
        }
        else if (gr.isValid(adjacentLoc2) && gr.get(adjacentLoc2) == null) {
            this.setDirection(newDirection2);
            this.moveTo(adjacentLoc2);
        }
        else if (gr.isValid(adjacentLoc3) && gr.get(adjacentLoc3) == null) {
            this.setDirection(newDirection3);
            this.moveTo(adjacentLoc3);
        }
        else if (gr.isValid(adjacentLoc4) && gr.get(adjacentLoc4) == null) {
            this.setDirection(newDirection4);
            this.moveTo(adjacentLoc4);
        }
        else if (gr.isValid(adjacentLoc5) && gr.get(adjacentLoc5) == null) {
            this.setDirection(newDirection5);
            this.moveTo(adjacentLoc5);
        }
    }
}
