package apcs.lucky7;

import java.util.Scanner;

public class Extension {
    public static void main(String[] args) {
        /*
        I completed an extension: This program now asks for player's choice in die and their lucky number.
        The program then uses these values to update the randomly generated numbers for dice_1 and dice_2 and
        updates the if statement within the while statement to check to see if the sum of the two dice values equals
        the user's chosen number. In addition, the player is also given a new option to play "doubles", where if they roll two of the same
        number, they immediately lose all of their earnings and the game ends.

        This demonstrates mastery because it takes the concepts utilized in the regular project and continued building
        on them by increasing user-friendliness and interaction, as well as including two additional loops that add
        crucial functionality to the extended project (the "doubles" function).
         */
        Scanner user_input = new Scanner(System.in);

        double initial_balance;
        int user_dice;
        int user_number;
        String user_confirmation;

        System.out.println("Welcome to Lucky Your Choice, the totally-not-rigged-against-the-player dice game!");
        System.out.println("Rules of the game:");
        System.out.println("1. Each play costs $1");
        System.out.println("2. Roll two totally-not-rigged dice.");
        System.out.println("3. If the two dice add to equal a number of your choosing, you win $5!");
        System.out.println("4. If the two dice add to something other than the number of your choosing, then you win nothing!");
        System.out.println("5. Enter your starting money balance, number of sides to the die, and the lucky number and enjoy the play!");

        System.out.print("Enter starting money balance: ");
        initial_balance = user_input.nextDouble();

        System.out.print("Enter a number of sides for the dice: ");
        user_dice = user_input.nextInt();

        System.out.print("Enter a number to play to (ex. 4 instead of 7): ");
        user_number = user_input.nextInt();
        user_input.nextLine();

        System.out.print("Would you like to play with doubles (rolled two of the same number) (y/n)? ");
        user_confirmation = user_input.nextLine();

        System.out.println("You entered: " + initial_balance + " dollars, " + user_dice + " number of sides to the die, and " + user_number + " as your lucky number. Good luck!");

        System.out.println();

        double balance = initial_balance;
        double max_balance = initial_balance;

        int dice_1 = (int)(Math.random() * user_dice + 1);
        int dice_2 = (int)(Math.random() * user_dice + 1);

        int count = 0;
        int max_roll = 0;

        int dice_total;

        int win_total = 0;

        if (user_confirmation.equals("y")){
            while (balance > 0) {
                dice_total = dice_1 + dice_2;
                count = count + 1;

                if (dice_1 == dice_2) {
                    System.out.print("Roll " + count + ": " + dice_1 + ", " + dice_2 + "  Total: " + dice_total + "  DOUBLES! LOSE!  Starting balance: $" + balance);
                    balance = 0;
                    System.out.println("  Ending Balance: $" + balance);

                    dice_1 = (int)(Math.random() * user_dice + 1);
                    dice_2 = (int)(Math.random() * user_dice + 1);
                }
                else if (dice_total == user_number){
                    System.out.print("Roll " + count + ": " + dice_1 + ", " + dice_2 + "  Total: " + dice_total + "  WIN!  Starting balance: $" + balance);
                    balance = balance + 4;
                    System.out.println("  Ending Balance: $" + balance);

                    win_total = win_total + 1;

                    dice_1 = (int)(Math.random() * user_dice + 1);
                    dice_2 = (int)(Math.random() * user_dice + 1);
                }
                else {
                    System.out.print("Roll " + count + ": " + dice_1 + ", " + dice_2 + "  Total: " + dice_total + "  LOSE!  Starting balance: $" + balance);
                    balance = balance - 1;
                    System.out.println("  Ending Balance: $" + balance);

                    dice_1 = (int)(Math.random() * user_dice + 1);
                    dice_2 = (int)(Math.random() * user_dice + 1);
                }

                if (balance >= max_balance) {
                    max_balance = balance;
                    max_roll = count;
                }
            }
        }
        else {
            while (balance > 0) {
                dice_total = dice_1 + dice_2;
                count = count + 1;

                if (dice_total == user_number){
                    System.out.print("Roll " + count + ": " + dice_1 + ", " + dice_2 + "  Total: " + dice_total + "  WIN!  Starting balance: $" + balance);
                    balance = balance + 4;
                    System.out.println("  Ending Balance: $" + balance);

                    dice_1 = (int)(Math.random() * user_dice + 1);
                    dice_2 = (int)(Math.random() * user_dice + 1);
                }
                else {
                    System.out.print("Roll " + count + ": " + dice_1 + ", " + dice_2 + "  Total: " + dice_total + "  LOSE!  Starting balance: $" + balance);
                    balance = balance - 1;
                    System.out.println("  Ending Balance: $" + balance);

                    dice_1 = (int)(Math.random() * user_dice + 1);
                    dice_2 = (int)(Math.random() * user_dice + 1);
                }

                if (balance >= max_balance) {
                    max_balance = balance;
                    max_roll = count;
                }
            }
        }

        System.out.println();
        System.out.println("You broke after " + count + " rolls.");
        System.out.println("You won " + win_total + " rolls.");
        System.out.println("You should have stopped after " + max_roll + " rolls when your balance was $" + max_balance);
    }
}
