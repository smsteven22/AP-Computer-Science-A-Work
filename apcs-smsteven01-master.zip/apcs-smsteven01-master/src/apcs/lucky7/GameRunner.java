package apcs.lucky7;

import java.util.Scanner;

public class GameRunner {
    public static void main(String[] args) {
        Scanner user_input = new Scanner(System.in);

        double initial_balance;

        System.out.println("Welcome to Lucky 7, the totally-not-rigged-against-the-player dice game!");
        System.out.println("Rules of the game:");
        System.out.println("1. Each play costs $1");
        System.out.println("2. Roll two totally-not-rigged dice.");
        System.out.println("3. If the two dice add to equal 7, you win $5!");
        System.out.println("4. If the two dice add to something other than 7, then you win nothing!");
        System.out.println("5. Enter your starting money balance and enjoy the play!");

        initial_balance = user_input.nextDouble();

        System.out.println("You entered: " + initial_balance + " dollars. Good luck!");

        double balance = initial_balance;
        double max_balance = initial_balance;

        int dice_1 = (int)(Math.random() * 6 + 1);
        int dice_2 = (int)(Math.random() * 6 + 1);

        int count = 0;
        int max_roll = 0;

        int dice_total;

        int win_total = 0;

        while (balance > 0) {
            dice_total = dice_1 + dice_2;
            count = count + 1;

            if (dice_total == 7){
                System.out.print("Roll " + count + ": " + dice_1 + ", " + dice_2 + "  Total: " + dice_total + "  WIN!  Starting balance: $" + balance);
                balance = balance + 4;
                System.out.println("  Ending Balance: $" + balance);

                win_total = win_total + 1;

                dice_1 = (int)(Math.random() * 6 + 1);
                dice_2 = (int)(Math.random() * 6 + 1);
            }
            else {
                System.out.print("Roll " + count + ": " + dice_1 + ", " + dice_2 + "  Total: " + dice_total + "  LOSE!  Starting balance: $" + balance);
                balance = balance - 1;
                System.out.println("  Ending Balance: $" + balance);

                dice_1 = (int)(Math.random() * 6 + 1);
                dice_2 = (int)(Math.random() * 6 + 1);
            }

            if (balance >= max_balance) {
                max_balance = balance;
                max_roll = count;
            }
        }
        System.out.println("You broke after " + count + " rolls.");
        System.out.println("You won " + win_total + " rolls.");
        System.out.println("You should have stopped after " + max_roll + " rolls when your balance was $" + max_balance);




    }
}
