package apcs.student;
/*
    I completed an extension: This program takes the Student project and ensures that test scores that have not yet been set are not included
    in the average and maximum calculations. The initial conditions for test scores are 0.0, and the program ensures that the scores of 0.0
    are not included through multiple if, else if, and else statements.

    This extension demonstrates mastery because it utilizes multiple if, else if, and else statements, often nested inside one another, to ensure
    that an accurate calculation of average score and maximum score is made. Multiple logical operators are used within the if, else if, and
    else statements to complete calculations, connecting Unit 1 concepts with Unit 2 concepts, therefore demonstrating further mastery of
    material.

    NO changes to the runner were made to make this extension work. See ExtensionRunner class for Extension object execution.
 */
public class Extension {
    private String studentName;
    private int studentID;
    private double testScore1;
    private double testScore2;
    private double testScore3;

    public Extension(int id) {
        this.studentName = "First, Last";
        this.studentID = id;
        this.testScore1 = 0.0;
        this.testScore2 = 0.0;
        this.testScore3 = 0.0;
    }

    public Extension(String name, int id, double test1, double test2, double test3) {
        this.studentName = name;
        this.studentID = id;
        this.testScore1 = test1;
        this.testScore2 = test2;
        this.testScore3 = test3;
    }

    public String getName() {
        return this.studentName;
    }

    public void setName(String name) {
        this.studentName = name;
        return;
    }

    public int getID() {
        return this.studentID;
    }

    public double getScore(int test) {
        if (test == 1) {
            return this.testScore1;
        } else if (test == 2) {
            return this.testScore2;
        }
        else if (test == 3) {
            return this.testScore3;
        }
        else {
            return -1;
        }
    }

    public void setScore(int test, double score) {
        if (test == 1) {
            this.testScore1 = score;
        }
        else if (test == 2) {
            this.testScore2 = score;
        }
        else if (test == 3) {
            this.testScore3 = score;
        }
        else {
            return;
        }
    }

    // Start of Extension
    public double getAverage() {
        double testAverage;
        if (testScore1 == 0.0) {
            testAverage = (this.testScore2 + this.testScore3) / 2;
        }
        else if (testScore2 == 0.0) {
            testAverage = (this.testScore1 + this.testScore3) / 2;
        }
        else if (testScore3 == 0.0) {
            testAverage = (this.testScore1 + this.testScore2) / 2;
        }
        else if (testScore1 == 0.0 && testScore2 == 0.0) {
            testAverage = this.testScore3;
        }
        else if (testScore1 == 0.0 && testScore3 == 0.0) {
            testAverage = this.testScore2;
        }
        else if (testScore2 == 0.0 && testScore3 == 0.0) {
            testAverage = this.testScore1;
        }
        else {
            testAverage = ((this.testScore1 + this.testScore2 + this.testScore3) / 3);
        }
        return testAverage;
    }

    public double getMaximum() {
        if (testScore1 == 0.0) {
            if (testScore2 > testScore3) {
                return testScore2;
            }
            else {
                return testScore3;
            }
        }
        else if (testScore2 == 0.0) {
            if (testScore1 > testScore3) {
                return testScore1;
            }
            else {
                return testScore3;
            }
        }
        else if (testScore3 == 0.0) {
            if (testScore1 > testScore2) {
                return testScore1;
            }
            else {
                return testScore2;
            }
        }
        else if (testScore1 == 0.0 && testScore2 == 0.0) {
            return testScore3;
        }
        else if (testScore1 == 0.0 && testScore3 == 0.0) {
            return testScore2;
        }
        else if (testScore2 == 0.0 && testScore3 == 0.0) {
            return testScore1;
        }
        else {
            if (this.testScore1 > this.testScore2 && this.testScore1 > this.testScore3) {
                return this.testScore1;
            }
            else if (this.testScore2 > this.testScore1 && this.testScore2 > this.testScore3) {
                return this.testScore2;
            }
            else {
                return this.testScore3;
            }
        }
    }
    // End of Extension

    public String toString() {
        String info = "Student Name: " + this.studentName + "\nStudent ID: " + this.studentID + "\nTest Score 1: " + this.testScore1 + "\nTest Score 2: " + this.testScore2 + "\nTest Score 3: " + this.testScore3;
        return info;
    }

    public boolean equals (Student other) {
        if (this.studentID == other.getID()) {
            return true;
        }
        else {
            return false;
        }
    }
}
