package apcs.student;

public class Student {
    private String studentName;
    private int studentID;
    private double testScore1;
    private double testScore2;
    private double testScore3;

    public Student(int id) {
        this.studentName = "First, Last";
        this.studentID = id;
        this.testScore1 = 0.0;
        this.testScore2 = 0.0;
        this.testScore3 = 0.0;
    }

    public Student(String name, int id, double test1, double test2, double test3) {
        this.studentName = name;
        this.studentID = id;
        this.testScore1 = test1;
        this.testScore2 = test2;
        this.testScore3 = test3;
    }

    public String getName() {
        return this.studentName;
    }

    public void setName(String name) {
        this.studentName = name;
        return;
    }

    public int getID() {
        return this.studentID;
    }

    public double getScore(int test) {
        if (test == 1) {
            return this.testScore1;
        } else if (test == 2) {
            return this.testScore2;
        }
        else if (test == 3) {
            return this.testScore3;
        }
        else {
            return -1;
        }
    }

    public void setScore(int test, double score) {
        if (test == 1) {
            this.testScore1 = score;
        }
        else if (test == 2) {
            this.testScore2 = score;
        }
        else if (test == 3) {
            this.testScore3 = score;
        }
        else {
            return;
        }
    }

    public double getAverage() {
        double testAverage = ((this.testScore1 + this.testScore2 + this.testScore3) / 3);
        return testAverage;
    }

    public double getMaximum() {
        if (this.testScore1 > this.testScore2 && this.testScore1 > this.testScore3) {
            return this.testScore1;
        }
        else if (this.testScore2 > this.testScore1 && this.testScore2 > this.testScore3) {
            return this.testScore2;
        }
        else {
            return this.testScore3;
        }
    }

    public String toString() {
        String info = "Student Name: " + this.studentName + "\nStudent ID: " + this.studentID + "\nTest Score 1: " + this.testScore1 + "\nTest Score 2: " + this.testScore2 + "\nTest Score 3: " + this.testScore3;
        return info;
    }

    public boolean equals (Student other) {
        if (this.studentID == other.getID()) {
            return true;
        }
        else {
            return false;
        }
    }

}
