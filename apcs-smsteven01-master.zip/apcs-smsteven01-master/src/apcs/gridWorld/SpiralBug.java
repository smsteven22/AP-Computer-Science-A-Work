package apcs.gridWorld;

import info.gridworld.actor.Bug;

import java.awt.*;

public class SpiralBug extends Bug {
    private int steps;
    private int sideLength;

    public SpiralBug() {
        super();
        this.steps = 0;
        this.sideLength = 1;
        super.setColor(Color.GREEN);
    }

    public SpiralBug(int length) {
        super();
        this.steps = 0;
        this.sideLength = length;
        super.setColor(Color.GREEN);
    }

    public void act() {
        if (steps < sideLength && canMove()) {
            move();
            steps++;
        }
        else {
            turn();
            turn();
            steps = 0;
            sideLength++;
        }
    }
}
