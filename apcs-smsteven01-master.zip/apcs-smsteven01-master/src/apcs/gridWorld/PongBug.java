package apcs.gridWorld;

import info.gridworld.actor.Bug;

import java.awt.*;

/*
    I completed an extension: The new PongBug class creates a bug with all of the same behaviors as a normal bug, except
    for its act behavior now bounces off of the sides of the grid. The bug's bouncing behavior is determined by the
    angle at which it is moving towards the edge. Once the bug hits the edge, it turns 90 degrees and continues on its
    path until it hits another grid edge. If the bug hits a corner, the bug then moves one space vertically (up or down,
    depending on its location), and continues on its path in order to prevent retracing its steps.

    This extension demonstrates mastery because it exhibits my understanding of a bug's act and move behaviors
    in GridWorld and nested if statements. This program heavily utilizes nested if statements to check to see where the
    bug's position is relative to the edges of the grid and whether or not it can move. For example, if the bug hits the
    edge at a 45 degree angle (or moving North East), then the program will then check if the bug can turn 90 degrees to
    a 315 degree angle (moving North West) in which the bug would have hit the right edge of the grid. If this check
    returns false, then the program will then check if the bug's position is set to 135 degrees (moving South East), in
    which the bug would have hit the top edge of the grid. If this check also returns negative, that means that the bug
    has hit the upper right corner of the grid, in which the bug will face 180 degrees (South), move one square, and
    reset to a 225 degree angle (moving South West) to prevent the bug from continually retracing its steps. The program
    repeats these steps for every single direction that the bug could hit the edge of the grid from using a plethora of
    nested if and else statements. This extension also shows my ability to think through situations where the standard
    solution would not work and come up with a unique, achievable solution.
 */
public class PongBug extends Bug {
    public PongBug() {
        super();
        super.setColor(Color.WHITE);
        this.setDirection(45);
    }

    public void act() {
        if (canMove()) {
            move();
        } else {
            if (getDirection() == 45) {
                setDirection(315);
                if (canMove()) {
                    move();
                }
                else {
                    setDirection(135);
                    if (canMove()) {
                        move();
                    }
                    else {
                        setDirection(180);
                        move();
                        setDirection(225);
                    }
                }
            }
            else if (getDirection() == 135) {
                setDirection(225);
                if (canMove()) {
                    move();
                }
                else {
                    setDirection(45);
                    if (canMove()) {
                        move();
                    }
                    else {
                        setDirection(0);
                        move();
                        setDirection(315);
                    }
                }
            }
            else if (getDirection() == 225) {
                setDirection(135);
                if (canMove()) {
                    move();
                }
                else {
                    setDirection(315);
                    if (canMove()) {
                        move();
                    }
                    else {
                        setDirection(0);
                        move();
                        setDirection(45);
                    }
                }
            }
            else if (getDirection() == 315) {
                setDirection(45);
                if (canMove()) {
                    move();
                } else {
                    setDirection(225);
                    if (canMove()) {
                        move();
                    }
                    else {
                        setDirection(180);
                        move();
                        setDirection(135);
                    }
                }
            }
        }
    }
}
