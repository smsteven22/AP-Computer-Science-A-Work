package apcs.gridWorld;

import info.gridworld.actor.Bug;

import java.awt.*;

public class DancingBug extends Bug {

    public DancingBug() {
        super();
        super.setColor(Color.PINK);

    }

    public void act() {
        int direction = (int)(Math.random() * 9 + 1);
        if (direction == 1) {
            setDirection(90);
        }
        else if (direction == 2) {
            setDirection(45);
        }
        else if (direction == 4) {
            setDirection(315);
        }
        else if (direction == 5) {
            setDirection(270);
        }
        else if (direction == 6) {
            setDirection(225);
        }
        else if (direction == 7) {
            setDirection(180);
        }
        else if (direction == 8) {
            setDirection(135);
        }

        if (canMove()) {
            move();
        }
    }
}
