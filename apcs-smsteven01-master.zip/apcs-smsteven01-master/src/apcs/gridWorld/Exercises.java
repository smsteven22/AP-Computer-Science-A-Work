package apcs.gridWorld;

import info.gridworld.actor.Actor;
import info.gridworld.actor.ActorWorld;
import info.gridworld.grid.BoundedGrid;

public class Exercises {
    public static void main(String[] args) {
        BoundedGrid<Actor> grid = new BoundedGrid<>(50,40);
        ActorWorld world = new ActorWorld(grid);

        BoxBug boxy = new BoxBug(4);
        world.add(boxy);

        CircleBug circley = new CircleBug(4);
        world.add(circley);

        SpiralBug spiraly = new SpiralBug();
        world.add(spiraly);

        ZBug ziggy = new ZBug(4);
        world.add(ziggy);

        DancingBug dancy = new DancingBug();
        world.add(dancy);

        PongBug pongy = new PongBug();
        world.add(pongy);

        world.show();
    }
}
