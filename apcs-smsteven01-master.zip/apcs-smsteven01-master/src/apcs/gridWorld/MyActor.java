package apcs.gridWorld;

import info.gridworld.actor.Actor;

import java.awt.*;

public class MyActor extends Actor{
    public MyActor() {
        super();
        super.setColor(Color.GREEN);
    }

    public String toString() {
        return super.toString() + " Hi, I'm a MyActor!";
    }
}
