package apcs.gridWorld;

import info.gridworld.actor.Bug;

import java.awt.*;

public class ZBug extends Bug {
    private int steps;
    private int sideLength;
    private int part;

    public ZBug(int length) {
        super();
        this.steps = 0;
        this.sideLength = length;
        super.setColor(Color.BLUE);
        turn();
        turn();
        this.part = 1;
    }

    public void act() {
        if (this.steps < sideLength && part == 1 && canMove()) {
            move();
            this.steps += 1;
        } else if (this.steps == this.sideLength && part == 1) {
            turn();
            turn();
            turn();
            this.steps = 0;
            this.part = 2;
        } else if (this.steps < this.sideLength && part == 2) {
            move();
            this.steps += 1;
        } else if (this.steps == this.sideLength && part == 2) {
            turn();
            turn();
            turn();
            turn();
            turn();
            this.steps = 0;
            this.part = 3;
        } else if (this.steps <= this.sideLength && part == 3) {
            move();
            this.steps += 1;
        }

        /*
        for (steps = 0; steps < sideLength && canMove(); steps++) {
            move();
            steps++;
        }

        setDirection(135);

        for (steps = 0; steps < sideLength && canMove(); steps++) {
            move();
        }

        setDirection(-135);

        for (steps = 0; steps < sideLength && canMove(); steps++) {
            move();
         */
    }

}
