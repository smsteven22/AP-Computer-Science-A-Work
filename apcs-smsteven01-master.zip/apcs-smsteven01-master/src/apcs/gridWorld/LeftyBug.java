package apcs.gridWorld;

import info.gridworld.actor.Bug;
import info.gridworld.grid.Location;

import java.awt.*;

public class LeftyBug extends Bug {
    public LeftyBug() {
        super();
        super.setColor(Color.DARK_GRAY);
    }

    public void turn() {
        super.setDirection(getDirection() + Location.HALF_LEFT);
    }
}
