package apcs.gw3;

import info.gridworld.actor.Actor;
import info.gridworld.actor.Bug;
import info.gridworld.grid.Grid;
import info.gridworld.grid.Location;

import java.awt.*;

public class Jumper extends Bug {
    public Jumper() {
        super();
        super.setColor(Color.PINK);
    }

    public Jumper (Color jumpColor) {
        super();
        super.setColor(jumpColor);
    }

    public void act() {
        Grid<Actor> gr = this.getGrid();
        if (gr != null) {
            if (this.canMove()) {
                this.move();
            }
            else {
                Location loc = this.getLocation();
                Location nextSpace = loc.getAdjacentLocation(this.getDirection());
                Location secondSpace = nextSpace.getAdjacentLocation(this.getDirection());
                if (gr.isValid(nextSpace)) {
                    this.moveOne();
                }
                else {
                    this.turn();
                    this.turn();
                    this.turn();
                }
            }


        }
    }

    public void move() {
        Grid<Actor> gr = this.getGrid();
        if (gr != null) {
            Location loc = this.getLocation();
            Location nextSpace = loc.getAdjacentLocation(this.getDirection());
            Location secondSpace = nextSpace.getAdjacentLocation(this.getDirection());
            if (gr.isValid(secondSpace)) {
                this.moveTo(secondSpace);
            }
            else {
                this.removeSelfFromGrid();
            }
        }
    }

    public void moveOne() {
        Grid<Actor> gr = this.getGrid();
        if (gr != null) {
            Location loc = this.getLocation();
            Location next = loc.getAdjacentLocation(this.getDirection());
            if (gr.isValid(next)) {
                this.moveTo(next);
            } else {
                this.removeSelfFromGrid();
            }
        }
    }

    public boolean canMove() {
        Grid<Actor> gr = this.getGrid();
        if (gr == null) {
            return false;
        }
        else {
            Location loc = this.getLocation();
            Location nextSpace = loc.getAdjacentLocation(this.getDirection());
            Location secondSpace = nextSpace.getAdjacentLocation(this.getDirection());
            if (!gr.isValid(secondSpace)) {
                return false;
            }
            else if (gr.get(secondSpace) != null) {
                return false;
            }
            else {
                Actor neighbor = gr.get(secondSpace);
                return neighbor == null;
            }
        }
    }
}
