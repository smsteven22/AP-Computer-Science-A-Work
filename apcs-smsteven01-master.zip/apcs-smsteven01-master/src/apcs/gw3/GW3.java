package apcs.gw3;

import info.gridworld.actor.Actor;
import info.gridworld.actor.ActorWorld;
import info.gridworld.actor.Bug;
import info.gridworld.grid.BoundedGrid;
import info.gridworld.grid.Grid;
import info.gridworld.grid.Location;

import java.util.ArrayList;

public class GW3 {
    public static void main(String[] args) {
        Location loc = new Location(3,4);
        System.out.println(loc);
        System.out.println(loc.getAdjacentLocation(Location.NORTH));
        System.out.println(loc.getDirectionToward(new Location(2, 2)));
        System.out.println(loc.compareTo(new Location(1,3)));

        Grid<String> g = new BoundedGrid<String>(10, 10);
        g.put(new Location(1,2), "test 1");
        g.put(new Location (2, 1), "test 2");
        System.out.println(g);
        ArrayList<Location> locs = g.getOccupiedLocations();
        System.out.println(locs);

        ArrayList<Location> valid = g.getValidAdjacentLocations(new Location (3, 3));
        System.out.println(valid);

        ArrayList<Location> valid2 = g.getValidAdjacentLocations(new Location(0, 3));
        System.out.println(valid2);

        Location loc2 = new Location(2, 2);

        ArrayList<Location> occupied = g.getOccupiedAdjacentLocations(loc2);
        System.out.println(occupied);

        ArrayList<Location> empty = g.getEmptyAdjacentLocations(loc2);
        System.out.println(empty);

        ArrayList<String> obj = g.getNeighbors(loc2);
        System.out.println(obj);

        Grid<Actor> gr = new BoundedGrid<Actor>(20, 20);
        ActorWorld w = new ActorWorld(gr);
        Actor bob = new Actor();
        bob.putSelfInGrid(gr, new Location(2, 2));
        w.show();

        // GridWorld Part 3 CollegeBoard Lab:
        System.out.println("\nCollegeBoard Lab:");
        Location location = new Location(4,3);
        Location location2 = new Location (3, 4);
        int i = location.getRow();
        System.out.println(i);
        boolean b = location.equals(location2);
        System.out.println(b);
        Location location3 = location2.getAdjacentLocation(Location.SOUTH);
        int r = location3.getRow();
        int c = location3.getCol();
        System.out.println("(" + r + ", " + c + ")");
        int dir = location.getDirectionToward(new Location(6,5));
        System.out.println(dir);

        bob.removeSelfFromGrid();
        bob.putSelfInGrid(gr, new Location (2, 2));

        Bug jill = new Bug();
        jill.putSelfInGrid(gr, new Location (1, 0));
        jill.move();
        jill.removeSelfFromGrid();

    }
}
