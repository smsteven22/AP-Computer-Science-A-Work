package apcs.gw3;

import info.gridworld.actor.ActorWorld;
import info.gridworld.actor.Rock;
import info.gridworld.grid.BoundedGrid;
import info.gridworld.grid.Grid;
import info.gridworld.grid.Location;

import java.awt.*;

public class JumperRunner {
    public static void main(String[] args) {
        Grid gr = new BoundedGrid(10, 10);
        ActorWorld w = new ActorWorld(gr);
        Jumper j = new Jumper();
        j.putSelfInGrid(gr, new Location(9, 0));
        Rock r = new Rock();
        r.putSelfInGrid(gr, new Location(3, 5));
        Jumper j2 = new Jumper(Color.GREEN);
        j2.putSelfInGrid(gr, new Location(7, 0));
        w.show();
    }
}
