package apcs.fraction;

/*
I completed an extension: The added Simplify method takes the fraction object and simplifies
it down to its most simple form. The program uses an if loop to first determine if the fraction
is equal to 1/2 by checking if the modulo of the denominator divided by the numerator is equal
to zero. If so, calculations are performed on the numerator and denominator (separately) to
yield the new numerator and denominator values. If the fraction is not equal to 1/2, the method
then uses else if and else statements that use two for loops to simplify the fraction, first by
checking if the numerator and denominator are divisible by 3 by using the modulo operator. If both
the numerator and denominator are divisible by 2, then the method completes calculations until the
values of the numerator and denominator are zero (preventing an infinite loop), adding one to the
counter variable each time the for loop is completed. Once the first for loop is exited, the method
then subtracts 1 from the counter to account for the calculation that led to the numerator and
denominator equaling zero, and completes a second for loop. The second for loop then takes the new
count value and completes the same calculation on the numerator and denominator values, stopping one
loop before the previous for loop, resulting in the final simplified answer. If the numerator and
denominator are not divisible by 3, the method then checks if the numerator and denominator are
divisible by 2. If both the numerator and denominator are divisible by 2, the method completes the
same for loops as if the numerator and denominator were divisible by 3. The two new numerator and
denominator values are then used to create and return a new Fraction object representing the simplified values.

This extension demonstrates mastery because it exhibits my ability to think through errors and how
fractions can be simplified using Java concepts. In this extension, I was able to visualize the problem
and conceptualize its solution using material I already knew. This is evident by my ability to identify
numerous situations where a fraction might be simplified and was able to utilize an if statement to check
for these situations. In addition, I was able to overcome challenges with getting an infinite loop when
calculating the first for loop for a fraction not equaling 1/2. I was able to brainstorm and come up
with an idea that changed the while loop I was using into two for loops, the first being a counter
and the second using the counter value from the first loop to perform the necessary calculations
to simplify the fraction. In addition, this method demonstrates further mastery of material because
I was able to connect this Unit 2 project to Unit 1 concepts in multiple ways.
 */

/**
 * The Fraction class can be used to add, subract, multiply, divide, and compare
 * fractions without the loss of accuracy that comes with using the primitive double
 * data type.
 */
public class Fraction {
    private int numerator;
    private int denominator;

    /**
     * Constructs this Fraction using the passed int values n and d.
     * @param n the value to be set as the numerator.
     * @param d the value to be set as the denominator.
     */
    public Fraction(int n, int d) {
        numerator = n;
        denominator = d;
    }

    /**
     * Sets the numerator of this Fraction to the passed int value n.
     * @param n the value to be set as the numerator.
     */
    public void setNumerator(int n) {
        numerator = n;
    }

    /**
     * Sets the denominator of this Fraction to the passed int value d.
     * @param d the value to be set as the denominator.
     */
    public void setDenominator(int d) {
        denominator = d;
    }

    /**
     * Fetches the numerator of this Fraction and returns the result as an int.
     * @return an int that is the numerator of this Fraction.
     */
    public int getNumerator() {
        return numerator;
    }

    /**
     * Fetches the denominator of this Fraction and returns the result as an int.
     * @return an int that is the denominator of this Fraction.
     */
    public int getDenominator() {
        return denominator;
    }

    public String toString() {
        return numerator + "/" + denominator;
    }

    /**
     * Adds the passed Fraction to this Fraction and returns the result as a new Fraction.
     * @param other the Fraction to be added.
     * @return a new Fraction that is the sum of the passed Fraction and this Fraction.
     */
    public Fraction add(Fraction other) {
        int num = (this.numerator * other.getDenominator()) + (other.getNumerator() * this.denominator);
        int den = this.denominator * other.getDenominator();
        Fraction fract = new Fraction(num, den);
        return fract;
    }

    /**
     * Subracts the passed Fraction to this Fraction and returns the result as a new Fraction.
     * @param other the Fraction to be subtracted.
     * @return a new Fraction that is the difference of the passed Fraction and this Fraction.
     */
    public Fraction subtract(Fraction other) {
        int num = (this.numerator * other.getDenominator()) - (other.getNumerator() * this.denominator);
        int den = this.denominator * other.getDenominator();
        Fraction fract = new Fraction(num, den);
        return fract;
    }

    /**
     * Multiplies the passed Fraction to this Fraction and returns the result as a new Fraction.
     * @param other the Fraction to be multiplied.
     * @return a new Fraction that is the product of the passed Fraction and this Fraction.
     */
    public Fraction multiply(Fraction other) {
        int num = this.numerator * other.getNumerator();
        int den = this.denominator * other.getDenominator();
        Fraction fract = new Fraction(num, den);
        return fract;
    }

    /**
     * Divides the passed Fraction to this Fraction and returns the result as a new Fraction.
     * @param other the Fraction to be divided.
     * @return a new Fraction that is the quotient of the passed Fraction and this Fraction.
     */
    public Fraction divide(Fraction other) {
        int num = this.numerator * other.getDenominator();
        int den = this.denominator * other.getNumerator();
        Fraction fract = new Fraction(num, den);
        return fract;
    }

    public boolean equals(Fraction other) {
        Fraction difference = this.subtract(other);
        if (difference.getNumerator() == 0) {
            return true;
        }
        else {
            return false;
        }
    }

    /**
     * ~EXTENSION METHOD~
     * Simplifies this Fraction and returns the result as a new Fraction.
     * @return a new Fraction that is the simplified version of this Fraction.
     */
    // Start of Extension
    public Fraction simplify() {
        int simplifyNum = this.numerator;
        int simplifyDen = this.denominator;
        int count;
        int simplifyNum2 = this.numerator;
        int simplifyDen2 = this.denominator;

        if ((simplifyDen / simplifyNum) % 2 == 0){
            simplifyNum2 /= simplifyNum;
            simplifyDen2 /= simplifyNum;
        }
        else if ((simplifyNum % 3 == 0 && simplifyDen % 3 == 0) && (simplifyNum != 0 && simplifyDen != 0)) {
            for (count = 0; (simplifyNum % 3 == 0 && simplifyDen % 3 == 0) && (simplifyNum !=0 && simplifyDen != 0); count ++) {
                simplifyNum /= 3;
                simplifyDen /= 3;
            }
            count -= 1;

            for (int count2 = 0; count2 <= count; count2++) {
                simplifyNum2 /= 3;
                simplifyDen2 /= 3;
            }
        }
        else {
            for (count = 0; (simplifyNum % 2 == 0 && simplifyDen % 2 == 0) && (simplifyNum !=0 && simplifyDen != 0); count ++) {
                simplifyNum /= 2;
                simplifyDen /= 2;
            }
            count -= 1;

            for (int count2 = 0; count2 <= count; count2++) {
                simplifyNum2 /= 2;
                simplifyDen2 /=2;
            }
        }

        Fraction simplifiedFraction = new Fraction (simplifyNum2, simplifyDen2);
        return simplifiedFraction;
    }
    // End of Extension

}
