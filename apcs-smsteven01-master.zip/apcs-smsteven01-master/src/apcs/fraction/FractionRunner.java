package apcs.fraction;

import java.util.Scanner;

public class FractionRunner {
    public static void main(String[] args) {
        Scanner reader = new Scanner(System.in);

        Fraction f1 = new Fraction(1, 2);
        System.out.print("One Half = ");
        System.out.println(f1);

        f1.setNumerator(3);
        f1.setDenominator(4);

        int num = f1.getNumerator();
        int den = f1.getDenominator();

        System.out.print("Three Quarters = ");
        System.out.println(num + "/" + den);

        System.out.println();

        Fraction f2 = new Fraction(2, 3);
        System.out.print("Two thirds = ");
        System.out.println(f2);

        System.out.println();

        Fraction sum = f1.add(f2);
        System.out.println(f1 + " + " + f2 + " = " + sum);

        System.out.println();

        f2 = new Fraction(1, 2);
        sum = f1.add(f2);
        Fraction difference = f1.subtract(f2);
        Fraction product = f1.multiply(f2);
        Fraction quotient = f1.divide(f2);

        System.out.println("f1: " + f1);
        System.out.println("f2: " + f2);
        System.out.println("sum: " + sum);
        System.out.println("difference: " + difference);
        System.out.println("product: " + product);
        System.out.println("quotient: " + quotient);

        System.out.println();

        f1 = new Fraction(1, 2);
        f2 = new Fraction(1, 2);
        System.out.println(f1 + " == " + f2 + " = " + f1.equals(f2));
        System.out.println(f2 + " == " + f2 + " = " + f2.equals(f1));

        f2 = new Fraction(1, 3);
        System.out.println(f1 + " == " + f2 + " = " + f1.equals(f2));
        System.out.println(f2 + " == " + f1 + " = " + f2.equals(f1));

        f2 = new Fraction(2, 4);
        System.out.println(f1 + " == " + f2 + " = " + f1.equals(f2));
        System.out.println(f2 + " == " + f1 + " = " + f2.equals(f1));

        System.out.println();

        // Following code is to check Simplify Extension Method.
        Fraction f3 = new Fraction(3858, 5120);
        System.out.println(f3);
        Fraction simplify = f3.simplify();
        System.out.println("Simplified = " + simplify);

        Fraction f4 = new Fraction(50, 100);
        System.out.println(f4);
        Fraction simplify2 = f4.simplify();
        System.out.println("Simplified = " + simplify2);

        Fraction f5 = new Fraction(98, 100);
        System.out.println(f5);
        Fraction simplify3 = f5.simplify();
        System.out.println("Simplified = " + simplify3);

        Fraction f6 = new Fraction(3, 9);
        System.out.println(f6);
        Fraction simplify4 = f6.simplify();
        System.out.println("Simplified = " + simplify4);
        // Extension code ends here.

        System.out.println();

        System.out.println("Please specify a fraction numerator: ");
        int numValue1 = reader.nextInt();
        System.out.println("Please specify a fraction denominator: ");
        int denValue1 = reader.nextInt();
        Fraction userFraction1 = new Fraction(numValue1, denValue1);
        System.out.println("Please specify an operation (add, subtract, multiply, divide, simplify): ");
        String operation = reader.next();

        Fraction userFractionResult = new Fraction(0, 0);
        while (userFractionResult.getNumerator() == 0 && userFractionResult.getDenominator() == 0) {
            if (operation.equals("add")) {
                System.out.println("Please specify a fraction numerator: ");
                int numValue2 = reader.nextInt();
                System.out.println("Please specify a fraction denominator: ");
                int denValue2 = reader.nextInt();
                Fraction userFraction2 = new Fraction(numValue2, denValue2);

                userFractionResult = userFraction1.add(userFraction2);
                System.out.println("Resultant fraction: " + userFractionResult);
            } else if (operation.equals("subtract")) {
                System.out.println("Please specify a fraction numerator: ");
                int numValue2 = reader.nextInt();
                System.out.println("Please specify a fraction denominator: ");
                int denValue2 = reader.nextInt();
                Fraction userFraction2 = new Fraction(numValue2, denValue2);

                userFractionResult = userFraction1.subtract(userFraction2);
                System.out.println("Resultant fraction: " + userFractionResult);
            } else if (operation.equals("multiply")) {
                System.out.println("Please specify a fraction numerator: ");
                int numValue2 = reader.nextInt();
                System.out.println("Please specify a fraction denominator: ");
                int denValue2 = reader.nextInt();
                Fraction userFraction2 = new Fraction(numValue2, denValue2);

                userFractionResult = userFraction1.multiply(userFraction2);
                System.out.println("Resultant fraction: " + userFractionResult);
            } else if (operation.equals("divide")) {
                System.out.println("Please specify a fraction numerator: ");
                int numValue2 = reader.nextInt();
                System.out.println("Please specify a fraction denominator: ");
                int denValue2 = reader.nextInt();
                Fraction userFraction2 = new Fraction(numValue2, denValue2);

                userFractionResult = userFraction1.divide(userFraction2);
                System.out.println("Resultant fraction: " + userFractionResult);
            }
            // Extension functionality also included here:
            else if (operation.equals("simplify")) {
                userFractionResult = userFraction1.simplify();
                System.out.println("Resultant fraction: " + userFractionResult);
            }
            // End of extension functionality
            else {
                System.out.println("Not a valid operation. Please try again.");
                System.out.println("Please specify an operation (add, subtract, multiply, divide, simplify): ");
                operation = reader.next();
            }
        }
    }
}
