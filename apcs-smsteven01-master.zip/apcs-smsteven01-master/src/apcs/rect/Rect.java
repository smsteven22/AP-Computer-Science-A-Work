package apcs.rect;

public class Rect {
    // Instance variables define an object's state
    // Put their declarations right up top!
    // Private means that any other class (like a Runner) can't access the instance variables directly
    private double width;
    private double height;

    // A constructor is the code used to "create" a new instance
    // Usually it needs to set the instance variable to some default, initial value
    // A constructor is ALWAYS the same as the Class name and NEVER has a return type
    // We'll tag this as "public" since we DO want other classes like Runners to be able to access this:
    public Rect() {
        // Whenever you refer to an instance variable, it's best to prefix it with this. as a reminder that you are only changing the instance variable for ONE SPECIFIC instance of the class.
        this.width = 0.0;
        this.height = 0.0;
    }

    // Using getters/setters in a Runner is often very tedious
    // You can create an alternate Constructor that automatically sets your instance variables to specific starting values.
    public Rect (double w, double h) {
        this.width = w;
        this.height = h;
    }

    // This method only retrieves the width of a particular instance
    public double getWidth () {
        return this.width;
    }

    // This method lets you CHANGE the width of a particular instance
    public void setWidth (double w) {

        this.width = w;
    }

    public double getHeight () {

        return this.height;
    }

    public void setHeight (double h) {

        this.height = h;
    }

    public double getArea () {
        double area = this.width * this.height;
        return area;
    }

    public double getDiagonal () {
        double diagonal = Math.sqrt(Math.pow(this.width, 2) + Math.pow(this.height, 2));
        return diagonal;
    }

    public boolean equals (Rect other) {
        if ((this.width == other.getWidth()) && (this.height == other.getHeight())) {
            return true;
        }
        else {
            return false;
        }
    }

    public double getPerimeter () {
        double perimeter = (2 * this.width) + (2 * this.height);
        return perimeter;
    }
    // toString is a special method that Java uses to "convert" an object type into a String type.
    // It always returns a String with the current values of an instance's variables
    public String toString() {
        String info = "Rect: Width: " + this.width + " Height: " + this.height;
        return info;
        // Notice that the toString method does not actually print anything.
        // NEVER print to the console in the toString!
        // Let the Runner do all the printing!
    }
}
