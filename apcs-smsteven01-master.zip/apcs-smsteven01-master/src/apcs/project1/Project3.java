package apcs.project1;

import java.util.Scanner;

public class Project3 {
    public static void main(String[] args) {
        Scanner reader = new Scanner(System.in);
        double kilometers;
        System.out.print("Enter a number of kilometers: ");
        kilometers = reader.nextDouble();
        System.out.println("You entered: " + kilometers + " kilometers.");

        double minutes = 60 * 90;
        double n_m_conversion = minutes/10000;
        double nautical_miles = kilometers * n_m_conversion;

        System.out.println(kilometers + " kilometers in nautical miles is " + nautical_miles + " nautical miles.");

    }
}
