package apcs.project1;

import java.util.Scanner;
import java.lang.Math;

public class Extension {
    public static void main(String[] args) {
        Scanner reader = new Scanner (System.in);

        System.out.println();
        System.out.println("Welcome to a simple Java calculator!");
        System.out.println();
        System.out.println("This calculator performs five simple operations: addition, subtraction, multiplication, division, and calculating remainders");
        System.out.println("All you have to do is enter some information!");

        double firstNumber;
        System.out.print ("Enter the first number: ");
        firstNumber = reader.nextDouble ();
        reader.nextLine();

        double secondNumber;
        System.out.print ("Enter the second number: ");
        secondNumber = reader.nextDouble();
        reader.nextLine();
        System.out.println("You entered: " + firstNumber + " and " + secondNumber);

        System.out.println();
        System.out.println("Available Operations: ");

        String addition = "Addition";
        System.out.println(addition);

        String subtraction = "Subtraction";
        System.out.println(subtraction);

        String multiplication = "Multiplication";
        System.out.println(multiplication);

        String division = "Division";
        System.out.println(division);

        String mod = "Modulus";
        System.out.println(mod);

        String operation;
        System.out.print ("Enter an operation (MUST BE CAPITALIZED): ");
        operation = reader.nextLine();
        System.out.println("You entered " + operation);

        if (operation.equals(addition)){
            double sum;
            sum = firstNumber + secondNumber;
            System.out.println();
            System.out.println(sum);
            System.out.print("The sum of " + firstNumber + " and " + secondNumber + " is " + sum);
        }
        else if (operation.equals(subtraction)){
            double difference;
            difference = firstNumber - secondNumber;
            System.out.println();
            System.out.println(difference);
            System.out.println("The difference of " + firstNumber + " and " + secondNumber + " is " + difference);
        }
        else if (operation.equals(multiplication)){
            double product;
            product = firstNumber * secondNumber;
            System.out.println();
            System.out.println(product);
            System.out.println("The product of" + firstNumber + " and " + secondNumber + " is " + product);
        }
        else if (operation.equals(division)){
            double quotient;
            quotient = firstNumber / secondNumber;
            System.out.println();
            System.out.println(quotient);
            System.out.println("The quotient of " + firstNumber + " and " + secondNumber + " is " + quotient);
        }
        else if (operation.equals(mod)){
            double remainder;
            remainder = firstNumber % secondNumber;
            System.out.println();
            System.out.println(remainder);
            System.out.println("The modulus of " + firstNumber + " and " + secondNumber + " is " + remainder);
        }
        else{
            System.out.print("That is not an operation in this calculator!");
        }
    }
}
