package apcs.project1;

public class Project1 {
    public static void main(String[] args) {
        System.out.println("Name: Sophie Steven");
        System.out.println("Address: 603 Columbine Avenue, Broomfield CO 80020");
        System.out.println("Telephone Number: (303) 726-5485");
    }
}
