package apcs.project1;

public class Project2 {
    public static void main(String[] args) {
        System.out.println("--------------");
        System.out.println(" \\          /");
        System.out.println("  \\ YIELD  /");
        System.out.println("   \\      /");
        System.out.println("    \\    /");
        System.out.println("     \\  /");
        System.out.println("      \\/");
    }
}
