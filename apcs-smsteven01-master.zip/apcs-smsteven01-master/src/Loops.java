import java.sql.SQLOutput;

public class Loops {
    public static void main(String[] args) {
        // Practice 1:
        // 0, 1, 2, 3, 4, 5, 6, 7, 8
        for (int a = 0; a < 9; a++){
            System.out.print(a + " ");
        }

        System.out.println();
        System.out.println();

        // 7, 8, 9, 10, 11, 12
        for (int b = 7; b < 13; b++){
            System.out.print(b + " ");
        }

        System.out.println();
        System.out.println();

        // 12, 15, 18, 21, 24, 27, 30
        for (int c = 12; c < 31; c += 3){
            System.out.print(c + " ");
        }

        System.out.println();
        System.out.println();

        // 100, 98, 96, 94, 92 ... 4, 2, 0
        for (int d = 100; d >= 0; d -= 2){
            System.out.print(d + " ");
        }

        System.out.println();
        System.out.println();

        // Practice 2:
        // 25 random numbers in the range [1, 6]
        for (int f = 0; f < 26; f++){
            int e = (int)(Math.random() * 6 + 1);
            System.out.print(e + " ");
        }

        System.out.println();
        System.out.println();

        // Practice 3:
        // 10 coin flips
        for (int g = 0; g < 10; g++){
            double h = (Math.random());
            if (h >= 0.5){
                System.out.print("heads ");
            }
            else {
                System.out.print("tails ");
            }
        }

        System.out.println();
        System.out.println();

        // Practice 4:
        // Generate numbers until greater than 0.9
        double i = Math.random();
        int j = 0;
        while (i < 0.9){
            System.out.println(i);
            j = j + 1;
            i = Math.random();
        }
        System.out.print(i);

        System.out.println();
        System.out.println();

        // Practice 5:
        // Use a loop to display the fractions: 1/1, 1/2, 1/3, 1/4, ... 1/10
        for (int k = 1; k < 11; k++){
            double decimal = 1.0 / (int)k;
            System.out.println(decimal);
        }

        System.out.println();
        System.out.println();

        // Practice 6:
        // Use a loop to alternate 10 times: 1, -1, 1, -1, 1, -1
        for (int l = 1; l < 11; l++){
            if (l % 2 == 0){
                System.out.println(-1);
            }
            else {
                System.out.println(1);
            }
        }

        System.out.println();
        System.out.println();

        // Practice 7:
        // Use a loop to add up the numbers from 1 to 10: 1 + 2 + 3 + 4 + 5 + 6 + 7 + 8 + 9 + 10
        int m = 0;
        for (int n = 1; n < 11; n++){
            System.out.print(n + " + ");
            m = m + n;
        }
        System.out.println("0 = " + m);
    }
}
