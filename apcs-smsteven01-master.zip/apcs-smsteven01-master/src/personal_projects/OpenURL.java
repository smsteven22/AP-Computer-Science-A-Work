package personal_projects;

import java.awt.*;
import java.net.URI;

public class OpenURL {
    public static void main(String[] args) {
        try {
            Desktop desktop = java.awt.Desktop.getDesktop();
            URI oURL = new URI("https://www.youtube.com/watch?v=dQw4w9WgXcQ");
            desktop.browse(oURL);
        }
        catch(Exception e) {
            e.printStackTrace();
        }
    }
}
