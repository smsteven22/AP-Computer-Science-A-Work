package personal_projects;

import java.util.Scanner;

public class CollatzConjecture {
    private double seed;
    private int stepsCount;
    private double max;
    private boolean parse;

    public CollatzConjecture (double userSeed) {
        this.seed = userSeed;
        this.stepsCount = 0;
        this.max = userSeed;
        this.parse = false;
    }

    public double getSeed() {
        return this.seed;
    }

    public int getStepsCount() {
        return this.stepsCount;
    }

    public double getMax() {
        return this.max;
    }

    public boolean getParse() {
        return this.parse;
    }

    public void setSeed(int newSeed) {
        this.seed = newSeed;
    }

    public void setParse(boolean newParse) {
        this.parse = newParse;
    }

    public void calculation (boolean userParse) {
        this.parse = userParse;
        if (this.parse == true) {
            while (this.seed != 1) {
                if (this.seed % 2 == 0) {
                    this.seed = this.seed/2;
                    this.stepsCount++;
                    if (this.seed > this.max) {
                        this.max = this.seed;
                    }
                    System.out.println("Step Number: " + this.stepsCount + "; Calculation Result: " + this.seed);
                }
                else {
                    this.seed = (3 * this.seed) + 1;
                    this.stepsCount++;
                    if (this.seed > this.max) {
                        this.max = this.seed;
                    }
                    System.out.println("Step Number: " + this.stepsCount + "; Calculation Result: " + this.seed);
                }
            }
        }
        else {
            while (this.seed != 1) {
                if (this.seed % 2 == 0) {
                    this.seed = this.seed/2;
                    this.stepsCount++;
                    if (this.seed > this.max) {
                        this.max = this.seed;
                    }
                }
                else {
                    this.seed = (3 * this.seed) + 1;
                    this.stepsCount++;
                    if (this.seed > this.max) {
                        this.max = this.seed;
                    }
                }
            }
        }
    }

    public String toString() {
        String str = "Conjecture Result: " + this.seed + "; Steps taken: " + this.stepsCount + "; Max value: " + this.max;
        return str;
    }
    public static void main(String[] args) {
        Scanner reader = new Scanner (System.in);
        int tryCount = 0;
        double userInput = 0;
        boolean parseInput = false;
        while (tryCount < 1) {
            try {
                System.out.print ("Enter a number: ");
                userInput = reader.nextDouble();
                System.out.println("You entered: " + userInput);
                System.out.print("Would you like to parse through calculations? True or False: ");
                parseInput = reader.nextBoolean();
                System.out.println ("You entered: " + parseInput);
                tryCount++;
            }
            catch (Exception except) {
                System.out.println("That is not a valid answer. Please try again.");
                reader.nextLine();
            }
        }

        CollatzConjecture num = new CollatzConjecture(userInput);
        num.calculation(parseInput);
        System.out.println();
        System.out.println(num);
    }
}
