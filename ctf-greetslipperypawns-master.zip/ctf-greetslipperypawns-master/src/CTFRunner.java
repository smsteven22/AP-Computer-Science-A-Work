import ctf.CTFWorld;
import ctf.Team;
import teams.blueSampleTeam.BlueSampleTeam;
import teams.corns.CornsTeam;
import teams.redSampleTeam.RedSampleTeam;

import javax.swing.*;
import java.awt.*;

public class CTFRunner {

    public static void main(String[] args) {

        /*
            Starting Notes:
                - Offensive:
                    2 Perimeter
                    2 Buddy
                - Defensive
                    1 flag
                    1 line
                    2 floater
         */

        // create two teams
        Team a = new CornsTeam();
        Team b = new BlueSampleTeam();

        // build and display a CTFWorld
        CTFWorld world = new CTFWorld(a, b, 75);
        world.show();

        // wait for a winner
        while (!a.hasWon() && !b.hasWon()) {
        }

        // display popup alert with results
        String msg = "Game over! ";
        if (a.hasWon()) msg += a.getName() + " wins!\n\n";
        if (b.hasWon()) msg += b.getName() + " wins!\n\n";
        JOptionPane.showMessageDialog(null, msg + a.getStats() + "\n" + b.getStats());
    }
}
