package teams.corns;

import ctf.Player;
import info.gridworld.grid.Location;

import java.util.ArrayList;
import java.util.List;

public class FlagPlayer extends DefensivePlayer {


    public FlagPlayer(Location startLocation) {
        super(startLocation);
    }

    public Location getMoveLocation() {
        Location myLoc = this.getLocation();
        List<Location> possible = getGrid().getEmptyAdjacentLocations(getLocation());
        if (possible.size() < 6) {
            if (!locked.contains(myLoc)) {
                locked.add(myLoc);
            }

        }
        Location flagLoc = this.getMyTeam().getFlag().getLocation();
        int flagCol = flagLoc.getCol();
        int flagRow = flagLoc.getRow();
        int row = myLoc.getRow();
        int col = myLoc.getCol();
        int side = this.getMyTeam().getSide();


        ArrayList<Player> oppLoc = new ArrayList<Player>(this.getOtherTeam().getPlayers());
        for (Player opp : oppLoc) {
            Location opponentLoc = opp.getLocation();
            int enemyDir = myLoc.getDirectionToward(opponentLoc);
            Location towardEnemy = myLoc.getAdjacentLocation(enemyDir);
            int oppCol = opponentLoc.getCol();
            int oppRow = opponentLoc.getRow();

            if (opp.hasFlag()) {
                if (!locked.contains(towardEnemy) && possible.contains(towardEnemy)) {
                    return towardEnemy;
                }
            }

            if (flagCol - 8 < oppCol && oppCol < flagCol + 8) {
                 if (flagRow - 8 < oppRow && oppRow < flagRow + 8) {
                    if (!locked.contains(towardEnemy) && possible.contains(towardEnemy)) {
                        return towardEnemy;
                    }
                }
            }
        }

        if (side == 1) {
            if (col < flagCol - 5) {
                if (!locked.contains(new Location(row, col + 1)) && possible.contains(new Location(row, col + 1))) {
                    return new Location(row, col + 1);
                } else if (!locked.contains(new Location(row + 1, col + 1)) && possible.contains(new Location(row + 1, col + 1))) {
                    return new Location(row + 1, col + 1);
                } else if (!locked.contains(new Location(row - 1, col + 1)) && possible.contains(new Location(row - 1, col + 1))) {
                    return new Location(row - 1, col + 1);
                }
            } else {
                if (row > flagRow + 5) {
                    if (!locked.contains(new Location(row - 1, col)) && possible.contains(new Location(row - 1, col))) {
                        return new Location(row - 1, col);
                    } else if (!locked.contains(new Location(row, col + 1)) && possible.contains(new Location(row, col + 1))) {
                        return new Location(row, col + 1);
                    } else if (!locked.contains(new Location(row, col - 1)) && possible.contains(new Location(row, col - 1))) {
                        return new Location(row, col - 1);
                    }
                }
                else if (flagRow - 5 < row){
                    if (!locked.contains(new Location(row + 1, col)) && possible.contains(new Location(row + 1, col))) {
                        return new Location(row + 1, col);
                    } else if (!locked.contains(new Location(row, col + 1)) && possible.contains(new Location(row, col + 1))) {
                        return new Location(row, col + 1);
                    } else if (!locked.contains(new Location(row, col - 1)) && possible.contains(new Location(row, col - 1))) {
                        return new Location(row, col - 1);
                    }
                }
            }
        } else {
            if (col > flagCol + 5) {
                if (!locked.contains(new Location(row, col - 1)) && possible.contains(new Location(row, col - 1))) {
                    return new Location(row, col - 1);
                } else if (!locked.contains(new Location(row + 1, col - 1)) && possible.contains(new Location(row + 1, col - 1))) {
                    return new Location(row + 1, col - 1);
                } else if (!locked.contains(new Location(row - 1, col - 1)) && possible.contains(new Location(row - 1, col - 1))) {
                    return new Location(row - 1, col - 1);
                }
            } else {
                if (row > flagRow + 5) {
                    if (!locked.contains(new Location(row - 1, col)) && possible.contains(new Location(row - 1, col))) {
                        return new Location(row - 1, col);
                    } else if (!locked.contains(new Location(row, col + 1)) && possible.contains(new Location(row, col + 1))) {
                        return new Location(row, col + 1);
                    } else if (!locked.contains(new Location(row, col - 1)) && possible.contains(new Location(row, col - 1))) {
                        return new Location(row, col - 1);
                    }
                }
                else if (flagRow - 5 < row ){
                    if (!locked.contains(new Location(row + 1, col)) && possible.contains(new Location(row + 1, col))) {
                        return new Location(row + 1, col);
                    } else if (!locked.contains(new Location(row, col + 1)) && possible.contains(new Location(row, col + 1))) {
                        return new Location(row, col + 1);
                    } else if (!locked.contains(new Location(row, col - 1)) && possible.contains(new Location(row, col - 1))) {
                        return new Location(row, col - 1);
                    }
                }
            }
        }


        return null;

    }
}
