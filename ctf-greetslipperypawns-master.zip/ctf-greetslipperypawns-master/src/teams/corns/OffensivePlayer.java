package teams.corns;

import ctf.Player;
import info.gridworld.grid.Location;

import java.util.ArrayList;
import java.util.List;

public class OffensivePlayer extends Player {

    public ArrayList<Location> locked = new ArrayList<>();

    public OffensivePlayer(Location startLocation) {
        super(startLocation);
    }

    @Override
    public Location getMoveLocation() {
        return this.getOtherTeam().getFlag().getLocation();
    }
}
