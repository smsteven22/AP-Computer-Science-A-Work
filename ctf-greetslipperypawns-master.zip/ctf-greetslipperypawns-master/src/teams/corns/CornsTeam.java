package teams.corns;

import ctf.Team;
import info.gridworld.grid.Location;

import java.awt.*;
import java.net.URI;

public class CornsTeam extends Team {

	public CornsTeam() {
		// set up Team through superconstructor
		super(Color.YELLOW);

		super.addPlayer(new PerimeterPlayer(new Location(5 + (int)(Math.random() * 3 - 1), 30)));
		super.addPlayer(new PerimeterPlayer(new Location(10 + (int)(Math.random() * 3 - 1), 30)));

		super.addPlayer(new FloaterPlayer(new Location(15 + (int)(Math.random() * 3 - 1), 30)));
		super.addPlayer(new FloaterPlayer(new Location(20 + (int)(Math.random() * 3 - 1), 30)));

		super.addPlayer(new LinePlayer(new Location(25 + (int)(Math.random()*3 - 1), 30)));

		super.addPlayer(new FlagPlayer(new Location(35 + (int)(Math.random()*3 - 1), 30)));

		BuddyPlayer b1 = new BuddyPlayer(new Location(40, 30));
		BuddyPlayer b2 = new BuddyPlayer(new Location(41, 30));

		super.addPlayer(b1);
		super.addPlayer(b2);

		b1.setBuddy(b2);
		b2.setBuddy(b1);
	}

}