package teams.corns;

import info.gridworld.grid.Location;

import java.util.List;

public class LinePlayer extends DefensivePlayer {
    private int rowInc = 1;

    public LinePlayer(Location startLocation) {
        super(startLocation);
    }

    public Location getMoveLocation() {
        Location myLoc = this.getLocation();
        int col = myLoc.getCol();
        int row = myLoc.getRow();

        List<Location> possible = getGrid().getEmptyAdjacentLocations(getLocation());
        Location backup = null;

        if (possible.size() < 6) {
            if (!locked.contains(myLoc)) {
                locked.add(myLoc);
            }
        }
        int index = (int)(Math.random() * possible.size());
        while (backup == null) {
            if (!locked.contains(possible.get(index))) {
                backup = possible.get(index);
            }
            else {
                index = (int)(Math.random() * possible.size());
            }
        }

        int side = this.getMyTeam().getSide();

        if (side == 0) {
            if (col >= 44 && col < 49) {
                if (row <= 2) {
                    this.rowInc = 1;
                }
                else if (row >= 47) {
                    this.rowInc = -1;
                }
                if (!locked.contains(new Location(row + rowInc, col)) && possible.contains(new Location(row + rowInc, col))) {
                    return new Location(row + rowInc, col);
                }
            }
            else {
                if (col > 49) {
                    if (!locked.contains(new Location(row, col - 1)) && possible.contains(new Location(row, col - 1))) {
                        return new Location(row, col - 1);
                    }
                }
                else if (col < 44) {
                    if (!locked.contains(new Location(row, col + 1)) && possible.contains(new Location(row, col + 1))) {
                        return new Location(row, col + 1);
                    }
                }
            }

        }
        else {
            if (col >= 51 && col < 56) {

                if (row <= 2) {
                    this.rowInc = 1;
                } else if (row >= 47) {
                    this.rowInc = -1;
                }

                if (!locked.contains(new Location(row + rowInc, col)) && possible.contains(new Location(row + rowInc, col))) {
                    return new Location(row + rowInc, col);
                }
            } else {
                if (col > 56) {
                    if (!locked.contains(new Location(row, col - 1)) && possible.contains(new Location(row, col - 1))) {
                        return new Location(row, col - 1);
                    }
                }
                else if (col < 51) {
                    if (!locked.contains(new Location(row, col + 1)) && possible.contains(new Location(row, col + 1))) {
                        return new Location(row, col + 1);
                    }
                }
            }
        }

        return backup;
    }
}
