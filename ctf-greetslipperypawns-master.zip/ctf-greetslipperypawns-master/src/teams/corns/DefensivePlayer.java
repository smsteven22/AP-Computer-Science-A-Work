package teams.corns;

import ctf.Player;
import info.gridworld.grid.Location;

import java.util.ArrayList;
import java.util.List;

public class DefensivePlayer extends Player {

    public ArrayList<Location> locked = new ArrayList<>();

    public DefensivePlayer(Location startLocation) {
        super(startLocation);
    }

    @Override
    public Location getMoveLocation() {
        return new Location(this.getLocation().getRow()+1, this.getLocation().getCol()+1);
    }
}
