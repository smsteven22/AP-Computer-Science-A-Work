package teams.corns;

import ctf.Player;
import info.gridworld.grid.Location;

import java.util.ArrayList;
import java.util.List;

public class FloaterPlayer extends DefensivePlayer{

    public FloaterPlayer(Location startLocation) {
        super(startLocation);
    }

    public Location getMoveLocation(){

        Location myLoc = this.getLocation();
        List<Location> possible = getGrid().getEmptyAdjacentLocations(getLocation());
        Location backup = null;
        int side = this.getMyTeam().getSide();
        int lim;
        if (side == 0) {
            lim = 49;
        }
        else {
            lim = 51;
        }
        if (possible.size()<6) {
            if (!locked.contains(myLoc)) {
                locked.add(myLoc);
            }
        }
        int index = (int)(Math.random()*possible.size());
        while (backup == null) {

                if (!locked.contains(possible.get(index))) {
                    if (side == 0) {
                        if (possible.get(index).getCol() < 49) {
                            backup = possible.get(index);
                        }
                    }
                    else {
                        if (possible.get(index).getCol() > 51) {
                            backup = possible.get(index);
                        }
                    }
                } else {
                    index = (int)(Math.random()*possible.size());
                }

        }

        ArrayList<Player> oppLoc = new ArrayList<Player>(this.getOtherTeam().getPlayers());
        for (Player opp : oppLoc) {
            Location opponentLoc = opp.getLocation();
            int oppCol = opponentLoc.getCol();
            int oppSide;
            if (oppCol < 50) {
                oppSide = 0;
            }
            else {
                oppSide = 1;
            }

            if (opp.hasFlag()) {
                int enemyDir = myLoc.getDirectionToward(opponentLoc);
                Location towardEnemy = myLoc.getAdjacentLocation(enemyDir);

                if (!locked.contains(towardEnemy) && possible.contains(towardEnemy)) {
                    return towardEnemy;
                }
            }

            if (oppSide == side) {
                int enemyDir = myLoc.getDirectionToward(opponentLoc);
                Location towardEnemy = myLoc.getAdjacentLocation(enemyDir);

                        if (!locked.contains(towardEnemy) && possible.contains(towardEnemy)) {
                            return towardEnemy;
                        }


            }
        }

        return backup;

    }

}
