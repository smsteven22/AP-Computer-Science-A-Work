package teams.corns;

import ctf.Player;
import info.gridworld.grid.Location;

import java.awt.*;
import java.net.URI;
import java.util.List;

public class BuddyPlayer extends OffensivePlayer {


    private BuddyPlayer buddy;

    public BuddyPlayer(Location startLocation) {
        super(startLocation);
    }

    public void setBuddy(BuddyPlayer b) {
        this.buddy = b;
    }

    @Override
    public Location getMoveLocation() {
        Location myLoc = this.getLocation();
        Location budLoc = this.buddy.getLocation();

        int myLocRow = myLoc.getRow();
        int myLocCol = myLoc.getCol();

        int budLocRow = budLoc.getRow();
        int budLocCol = budLoc.getCol();

        List<Location> possible = getGrid().getEmptyAdjacentLocations(getLocation());
        Location backup = null;

        int side = this.getMyTeam().getSide();

        if (possible.size() < 6) {
            if (!locked.contains(myLoc)) {
                locked.add(myLoc);
            }
        }
        int index = (int) (Math.random() * possible.size());
        while (backup == null) {
            if (!locked.contains(possible.get(index))) {
                backup = possible.get(index);
            } else {
                index = (int) (Math.random() * possible.size());
            }
        }

        if (this.hasFlag()) {
            int sideDir = myLoc.getDirectionToward(this.getMyTeam().getFlag().getLocation());
            Location towardSide = myLoc.getAdjacentLocation((sideDir));
            if (!locked.contains(towardSide) && possible.contains(towardSide)) {
                return towardSide;
            }
        } else if (side == 0 && (this.buddy.getLocation().getCol() >= 0 && this.buddy.getLocation().getCol() < 50)) {
            int flagDir = myLoc.getDirectionToward(this.getOtherTeam().getFlag().getLocation());
            Location towardFlag = myLoc.getAdjacentLocation(flagDir);
            if (!locked.contains(towardFlag) && possible.contains(towardFlag)) {
                return towardFlag;
            }
        } else if (side == 1 && (this.buddy.getLocation().getCol() >= 50 && this.buddy.getLocation().getCol() < 100)) {
            int flagDir2 = myLoc.getDirectionToward(this.getOtherTeam().getFlag().getLocation());
            Location towardFlag2 = myLoc.getAdjacentLocation(flagDir2);
            if (!locked.contains(towardFlag2) && possible.contains(towardFlag2)) {
                return towardFlag2;
            }
        } else if (Math.abs(myLocRow - budLocRow) >= 10 || Math.abs(myLocCol - budLocCol) >= 10) {
            int buddyDir = myLoc.getDirectionToward(this.buddy.getLocation());
            Location towardBuddy = myLoc.getAdjacentLocation(buddyDir);
            if (!locked.contains(towardBuddy) && possible.contains(towardBuddy)) {
                return towardBuddy;
            }
        } else {
            int flagDir3 = myLoc.getDirectionToward(this.getOtherTeam().getFlag().getLocation());
            Location towardFlag3 = myLoc.getAdjacentLocation(flagDir3);
            if (!locked.contains(towardFlag3) && possible.contains(towardFlag3)) {
                return towardFlag3;
            }
        }
        return backup;
    }


}
