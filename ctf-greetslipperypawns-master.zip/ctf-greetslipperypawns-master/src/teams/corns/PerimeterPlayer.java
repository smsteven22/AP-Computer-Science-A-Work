package teams.corns;

import info.gridworld.grid.Location;

import java.util.List;

public class PerimeterPlayer extends OffensivePlayer {

    public PerimeterPlayer(Location startLocation) {
        super(startLocation);
    }

    public Location getMoveLocation() {
        Location currLoc = this.getLocation();
        int row = currLoc.getRow();
        int col = currLoc.getCol();

        Location enemyFlag = this.getOtherTeam().getFlag().getLocation();
        int flagCol = enemyFlag.getCol();
        int flagRow = enemyFlag.getRow();

        List<Location> possible = getGrid().getEmptyAdjacentLocations(getLocation());
        Location backup = null;

        if (possible.size() < 6) {
            if (!locked.contains(currLoc)) {
                locked.add(currLoc);
            }
        }
        int index = (int) (Math.random() * possible.size());
        while (backup == null) {
            if (!locked.contains(possible.get(index))) {
                backup = possible.get(index);
            } else {
                index = (int) (Math.random() * possible.size());
            }
        }

        if (this.hasFlag()) {
            if (row >= 8) {
                if (!locked.contains(new Location(row - 1, col)) && possible.contains(new Location(row - 1, col))) {
                    return new Location(row - 1, col);
                }
            } else {
                if (this.getMyTeam().getSide() == 0) {
                    if (!locked.contains(new Location(row, col - 1)) && possible.contains(new Location(row, col - 1))) {
                        return new Location(row, col - 1);
                    }
                } else {
                    if (!locked.contains(new Location(row, col + 1)) && possible.contains(new Location(row, col + 1))) {
                        return new Location(row, col + 1);
                    }
                }
            }
        } else {
            if (col >= flagCol - 3 && col <= flagCol + 3) {
                if (row != flagRow) {
                    if (!locked.contains(new Location(row - 1, col)) && possible.contains(new Location(row - 1, col))) {
                        return new Location(row - 1, col);
                    }
                }
                else {
                    if (col > flagCol) {
                        if (!locked.contains(new Location(row, col - 1)) && possible.contains(new Location(row, col - 1))) {
                            return new Location(row, col - 1);
                        }
                    }
                    else {
                        if (!locked.contains(new Location(row, col + 1)) && possible.contains(new Location(row, col + 1))) {
                            return new Location(row, col + 1);
                        }
                    }
                }
            }
            else {
                if (row >= 43) {
                    if (col > flagCol) {
                        if (!locked.contains(new Location(row, col - 1)) && possible.contains(new Location(row, col - 1))) {
                            return new Location(row, col - 1);
                        }
                    } else {
                        if (!locked.contains(new Location(row, col + 1)) && possible.contains(new Location(row, col + 1))) {
                            return new Location(row, col + 1);
                        }
                    }
                }
                else {
                    if (!locked.contains(new Location(row + 1, col)) && possible.contains(new Location(row + 1, col))) {
                        return new Location(row + 1, col);
                    }
                }
            }
        }
        return backup;
    }
}

